# shellcheck shell=sh
#
# SEM SHEBANG, e é decisão, não esquecimento: este ficheiro é SOURCED por
# quem conduz o instalador, nunca executado directamente -- é biblioteca de
# funções, não programa. A trava de higiene do CI (§8 do CLAUDE.md) exige
# modo 100755 em todo `*.sh` versionado que comece por `#!`; marcar isto
# como executável obrigava a manter um bit que não serve para nada, só para
# um ficheiro que ninguém corre com `./idiomas.sh`. O mesmo padrão já existe
# em `poc/lab/common.sh`.
#
# idiomas.sh -- catálogo de mensagens do instalador do CPE, em três idiomas.
#
#   . "$(dirname "$0")/idiomas.sh"
#   idioma_define "$1"        # normaliza a entrada do utilizador/argumento
#   tela_linha "$(t disco_titulo)"
#
# PORQUÊ UMA FUNÇÃO POR IDIOMA, E NÃO UM `case "$NB_IDIOMA:$1"` ÚNICO: com
# quinze chaves x três idiomas, um `case` só tornava cada ramo ilegível ao
# repetir o prefixo do idioma quinze vezes. Uma função por idioma lê-se como
# a própria tradução -- quem quiser rever só o espanhol lê `_msg_es` e mais
# nada -- e o `t()` fica reduzido ao que é: um `case` de TRÊS ramos, não de
# quarenta e cinco.
#
# O instalador ARRANCA EM en-US (decisão do dono, ver o pedido que gerou
# este ficheiro): por isso o valor por omissão abaixo, e por isso o `*)` de
# `idioma_define` cai em en-US em vez de abortar -- um código de idioma
# desconhecido não pode travar a instalação, só mostrá-la na língua errada.
: "${NB_IDIOMA:=en-US}"

# Chaves cujo texto traz "%s" (apagar_aviso, apagar_pergunta,
# instalar_falhou) devolvem o "%s" LITERAL: `t()` só imprime, nunca formata.
# Quem chama substitui depois, porque só quem chama sabe o valor:
#
#   msg=$(t apagar_aviso)
#   printf "$msg\n" "$NOME_DO_DISCO"
#
# Nunca ao contrário -- nunca `tela_linha "$(t apagar_aviso)"` directo numa
# chave com "%s", ou o disco escolhido desaparece da tela em silêncio, e o
# operador confirma um apagamento sem saber qual disco está a apagar.

idioma_define() {
    case "$1" in
        pt-BR) NB_IDIOMA="pt-BR" ;;
        en-US) NB_IDIOMA="en-US" ;;
        es)    NB_IDIOMA="es" ;;
        *)     NB_IDIOMA="en-US" ;;
    esac
}

t() {
    case "$NB_IDIOMA" in
        pt-BR) _msg_pt_br "$1" ;;
        es)    _msg_es "$1" ;;
        *)     _msg_en_us "$1" ;;
    esac
}

# A palavra de confirmação é a única mensagem deste catálogo que decide algo
# (o operador escreve-a de volta para autorizar o apagamento do disco) --
# por isso fica em ASCII puro nos três idiomas, mesmo onde o resto do texto
# corrido leva acento: um terminal série marginal que engula um acento pode
# tornar a palavra impossível de reproduzir, e aí nada se confirma nunca.
idioma_palavra_apagar() {
    case "$NB_IDIOMA" in
        pt-BR) printf '%s' "APAGAR" ;;
        es)    printf '%s' "BORRAR" ;;
        *)     printf '%s' "ERASE" ;;
    esac
}

# A palavra com que uma tela ASSUME a instalação parada na outra (ver
# `assume_a_outra_tela`, no instalar.sh). ASCII pela mesma razão da de cima;
# diferente dela nos três idiomas, para nenhuma valer pela outra.
idioma_palavra_assumir() {
    case "$NB_IDIOMA" in
        pt-BR) printf '%s' "ASSUMIR" ;;
        es)    printf '%s' "ASUMIR" ;;
        *)     printf '%s' "TAKEOVER" ;;
    esac
}

# ---------------------------------------------------------------------------
# pt-BR
# ---------------------------------------------------------------------------
_msg_pt_br() {
    case "$1" in
        menu_idioma_titulo)   printf '%s' "Instalador NewBond" ;;
        # ASCII e nas TRÊS línguas, de propósito (ver o pedido): é a única
        # tela que se lê ANTES de o idioma estar escolhido.
        menu_idioma_opcoes)   printf '%s' "1) Portugues (Brasil)  2) English (US)  3) Espanol" ;;
        menu_idioma_pergunta) printf '%s' "Escolha de 1 a 3 [2]: " ;;
        disco_titulo)         printf '%s' "Escolha do disco de instalação" ;;
        # ASCII: cabeçalho da tabela mais perigosa da instalação (ver tela.sh).
        disco_cabecalho)      printf '%s' "  #  DISPOSITIVO      TAMANHO   MODELO" ;;
        disco_nenhum)         printf '%s' "Nenhum disco interno foi encontrado." ;;
        disco_pergunta)       printf '%s' "Número do disco: " ;;
        disco_invalido)       printf '%s' "Número fora da lista. Tente novamente." ;;
        apagar_aviso)         printf '%s' "AVISO: todo o conteúdo do disco %s será APAGADO." ;;
        apagar_pergunta)      printf '%s' "Digite %s para confirmar: " ;;
        apagar_recusado)      printf '%s' "Palavra não confere. Nada foi apagado." ;;
        instalar_a_escrever)  printf '%s' "Gravando o sistema no disco. NÃO DESLIGUE." ;;
        instalar_pronto)      printf '%s' "Instalação concluída." ;;
        instalar_falhou)      printf '%s' "Falha na instalação: %s" ;;
        simulacao_aviso)      printf '%s' "MODO SIMULAÇÃO: nada será escrito no disco." ;;
        # --- duas telas ao mesmo tempo (monitor e porta serial) ---
        consola_ocupada)       printf '%s' "A instalação já está sendo feita em outra tela (%s)." ;;
        consola_ocupada_dica)  printf '%s' "Use aquela tela, ou espere ela terminar." ;;
        consola_monitor)       printf '%s' "monitor e teclado" ;;
        consola_serie)         printf '%s' "porta serial" ;;
        instalar_ja_concluida) printf '%s' "A instalação já terminou." ;;
        tecla_enter_voltar)    printf '%s' "Aperte Enter para voltar: " ;;
        tecla_enter_recomecar) printf '%s' "Aperte Enter para começar de novo: " ;;
        # --- o fim: desligar ANTES de tirar o pendrive (a raiz vive nele) ---
        instalar_depois_desligar) printf '%s' "Depois que o aparelho desligar, retire o pendrive e ligue de novo." ;;
        tecla_enter_desligar)     printf '%s' "Aperte Enter para desligar o aparelho: " ;;
        instalar_desligando)      printf '%s' "Desligando... Quando a tela apagar, retire o pendrive." ;;
        # --- uma tela assume a instalação parada na outra ---
        consola_assumir_dica)     printf '%s' "Se ninguém está usando aquela tela, digite %s para usar esta." ;;
        consola_ocupada_gravando) printf '%s' "Aquela tela já está gravando o disco. Espere ela terminar." ;;
        consola_assumir_recusado) printf '%s' "Não dá para assumir: a outra tela já está gravando o disco." ;;
        consola_assumir_falhou)   printf '%s' "Não foi possível assumir a instalação. Tente de novo." ;;
        consola_assumida)         printf '%s' "Outra tela assumiu a instalação. Nada foi apagado." ;;
        # --- newbond-server-setup (concentrador), nao o instalador do CPE ---
        srv_titulo)            printf '%s' "Primeira configuração do concentrador NewBond" ;;
        srv_precisa_root)     printf '%s' "Este assistente precisa rodar como root." ;;
        srv_ja_configurado)   printf '%s' "Já existe config em %s; será substituída (cópia salva)." ;;
        srv_listen_pergunta)  printf '%s' "Endereço de escuta (ex.: :5001): " ;;
        srv_mtls_titulo)      printf '%s' "Configuração do mTLS" ;;
        srv_mtls_opcao_auto)     printf '%s' "1) Automático (recomendado): o concentrador cria a própria autoridade de certificados, e as CPEs são autorizadas pela tela da gerência" ;;
        srv_mtls_opcao_arquivos) printf '%s' "2) mTLS com os meus arquivos (já tenho certificado, chave e CA)" ;;
        srv_mtls_opcao_bancada)  printf '%s' "3) gerar conjunto de BANCADA" ;;
        srv_mtls_opcao_semtls)   printf '%s' "4) sem mTLS (não recomendado)" ;;
        srv_mtls_pergunta)    printf '%s' "Escolha 1-4: " ;;
        srv_cert_pergunta)    printf '%s' "Caminho do certificado deste servidor: " ;;
        srv_chave_pergunta)   printf '%s' "Caminho da chave privada: " ;;
        srv_ca_pergunta)      printf '%s' "Caminho da CA que assina os CPE: " ;;
        srv_ficheiro_falta)   printf '%s' "Não existe ou não pode ser lido: %s" ;;
        srv_bancada_aviso)    printf '%s' "AVISO: material de BANCADA, não é para produção." ;;
        srv_sem_mtls_aviso)   printf '%s' "AVISO: sem mTLS; a seção 6.1 exige mTLS." ;;
        srv_cpes_pergunta)    printf '%s' "Caminho da lista de CPE admitidos (vazio = nenhum): " ;;
        srv_resumo_titulo)    printf '%s' "Resumo do que será escrito" ;;
        srv_confirmar)        printf '%s' "Confirmar e escrever? [s/N]: " ;;
        srv_cancelado)        printf '%s' "Nada foi escrito." ;;
        srv_escrito)          printf '%s' "Configuração escrita em %s" ;;
        srv_copia)            printf '%s' "A anterior ficou guardada em %s" ;;
        srv_activar_pergunta) printf '%s' "Ativar e iniciar o serviço agora? [s/N]: " ;;
        srv_activado)         printf '%s' "Serviço ativado." ;;
        srv_nao_activado)     printf '%s' "Serviço NÃO ativado; comando para ativar depois:" ;;
        srv_auto_titulo)               printf '%s' "Modo automático — a CA própria do concentrador" ;;
        srv_auto_papel_opcao_principal) printf '%s' "1) Principal (recomendado): este concentrador tem a autoridade de certificados e aprova as CPEs" ;;
        srv_auto_papel_opcao_reserva)   printf '%s' "2) Reserva: entra em ação se o concentrador principal ficar fora do ar; um administrador aprova este concentrador no principal" ;;
        srv_auto_papel_pergunta)        printf '%s' "Escolha 1-2 [1]: " ;;
        srv_auto_enderecos_pergunta)   printf '%s' "Endereço público do concentrador (nome ou IP; pode ser mais de um, separados por vírgula): " ;;
        srv_auto_enderecos_vazio)      printf '%s' "É preciso pelo menos um endereço público: é o que as CPEs vão usar para chegar ao concentrador." ;;
        srv_auto_a_activar_gerencia)   printf '%s' "Ativando a gerência e aguardando a autoridade de certificados..." ;;
        srv_auto_gerencia_falhou_activar) printf '%s' "Não consegui ativar o newbond-gerencia." ;;
        srv_auto_ca_nao_apareceu)      printf '%s' "A autoridade de certificados não apareceu em %s. O newbond-server NÃO foi ativado." ;;
        srv_auto_ca_pronta)            printf '%s' "Autoridade de certificados pronta." ;;
        srv_auto_journal_titulo)       printf '%s' "Últimas linhas do serviço newbond-gerencia:" ;;
        srv_auto_server_falhou_activar) printf '%s' "newbond-gerencia está pronto, mas não consegui ativar o newbond-server." ;;
        srv_auto_resumo_titulo)        printf '%s' "Pronto! O concentrador está no ar." ;;
        srv_auto_painel_linha)         printf '%s' "Painel do administrador: %s (no primeiro acesso ele pede para criar a senha do administrador)" ;;
        srv_auto_firewall_titulo)      printf '%s' "Portas a abrir no firewall do datacenter:" ;;
        srv_auto_porta_video)             printf '%s' "%s/tcp — vídeo das CPEs" ;;
        srv_auto_porta_gerencia)          printf '%s' "5003/tcp — gerência das CPEs" ;;
        srv_auto_porta_adesao)            printf '%s' "5005/tcp — adesão de CPEs novas" ;;
        srv_auto_porta_tunel)             printf '%s' "51820/udp — acesso remoto (túnel)" ;;
        srv_auto_porta_abrir_painel)      printf '%s' "8444/tcp — abrir o painel das CPEs" ;;
        srv_auto_porta_painel_operadores) printf '%s' "8443/tcp — painel dos operadores (recomendado expor só na rede de gerência/VPN)" ;;
        srv_auto_porta_redir)             printf '%s' "%s/tcp — portas abertas (ligação das CPEs ao redirecionamento)" ;;
        srv_auto_porta_redir_regras)      printf '%s' "e cada porta que abrir em «Portas abertas no concentrador», no painel (só as origens que você liberar conseguem usá-la)" ;;
        srv_auto_redir_falhou_activar)    printf '%s' "O vídeo está no ar, mas não consegui ativar o newbond-redir (portas abertas). Veja: journalctl -u newbond-redir" ;;
        srv_redir_endereco_privado)       printf '%s' "O endereço %s é da rede interna e ninguém de fora o alcança: não foi usado como endereço público das portas abertas. A tela «Portas abertas no concentrador» vai pedir ao operador que confirme o endereço com o suporte. Para corrigir, rode este assistente de novo e inclua o IPv4 público do concentrador na lista." ;;
        # --- reserva (ADR 0138 §3, A3.2) ---
        srv_auto_reserva_titulo)             printf '%s' "Modo automático — concentrador de reserva" ;;
        srv_auto_reserva_principal_pergunta) printf '%s' "Endereço (nome ou IP) do concentrador principal: " ;;
        srv_auto_reserva_principal_vazio)    printf '%s' "É preciso informar o endereço do concentrador principal." ;;
        srv_auto_reserva_enderecos_pergunta) printf '%s' "Endereço público deste concentrador de reserva (nome ou IP; pode ser mais de um, separados por vírgula): " ;;
        srv_auto_reserva_codigo_titulo)      printf '%s' "Código de pareamento" ;;
        srv_auto_reserva_instrucao)          printf '%s' "No painel do concentrador principal, aprove o pedido deste concentrador de reserva conferindo o código %s" ;;
        srv_auto_reserva_codigo_nao_apareceu) printf '%s' "Não consegui obter o código de pareamento junto do concentrador principal. Confira o endereço e o código de convite: o convite vale 24 horas e só uma vez. Se preciso, gere outro no painel do principal e rode este assistente de novo." ;;
        # --- convite de pareamento (contrato de 2026-10-01, parte D) ---
        srv_auto_reserva_convite_pergunta)   printf '%s' "Código de convite gerado no painel do concentrador principal (ex.: ABCD-EFGH-JKMN): " ;;
        srv_auto_reserva_convite_invalido)   printf '%s' "Esse código não está no formato certo: são 12 letras e números, como ABCD-EFGH-JKMN (não existem as letras I, L, O e U). Confira e digite de novo." ;;
        srv_auto_reserva_convite_desistiu)   printf '%s' "Sem um código de convite válido não dá para parear. Gere um convite no painel do concentrador principal e rode este assistente de novo." ;;
        srv_auto_reserva_convite_ja_pareada) printf '%s' "Este concentrador de reserva já está pareado: deixe o código de convite em branco para manter como está." ;;
        srv_auto_reserva_convite_revogada)   printf '%s' "Este concentrador foi removido pelo concentrador principal. Para voltar a usá-lo como reserva, gere um convite no principal e informe-o aqui." ;;
        srv_auto_reserva_convite_guardado_pareada) printf '%s' "Este concentrador já está pareado: o código foi guardado e só será usado se o concentrador principal o remover." ;;
        srv_auto_reserva_convite_recusado)   printf '%s' "O concentrador principal recusou o código de convite: ele não existe, já foi usado ou venceu (vale 24 horas). Gere outro no painel do principal e rode este assistente de novo." ;;
        srv_auto_reserva_convite_resumo)     printf '%s' "Código de convite: será guardado em %s (não aparece aqui)" ;;
        srv_auto_reserva_convite_gravado)    printf '%s' "Código de convite guardado em %s." ;;
        srv_auto_reserva_convite_nao_gravou) printf '%s' "Não consegui guardar o código de convite em %s. Nada foi ativado." ;;
        srv_auto_reserva_nao_aprovado)       printf '%s' "Ninguém aprovou este concentrador de reserva a tempo. O newbond-server NÃO foi ativado." ;;
        srv_auto_reserva_tente_de_novo)      printf '%s' "A gerência continua ativa, aguardando aprovação. Assim que alguém autorizar no principal, rode este assistente de novo para concluir." ;;
        srv_auto_reserva_resumo_titulo)      printf '%s' "Pronto! Este concentrador de reserva está pareado." ;;
        # --- histórico de uso (ADR 0140, fatia H4) ---
        srv_historico_desligado) printf '%s' "Histórico de uso desligado: o banco (TimescaleDB) não está instalado. O concentrador funciona sem ele; para ligar, instale o pacote e volte a correr este assistente." ;;
        srv_historico_ligado)    printf '%s' "Histórico de uso ligado (TimescaleDB)." ;;
        srv_historico_simulado)  printf '%s' "Histórico de uso: sob --raiz, nada é executado no PostgreSQL (reiniciaria o serviço e criaria o papel/base newbond)." ;;
        srv_historico_falhou)    printf '%s' "Não consegui configurar o histórico de uso (%s). Histórico fica desligado; veja: journalctl -u postgresql" ;;
        # --- histórico ligado depois de uma atualização (newbond-server-setup --so-historico) ---
        srv_historico_so_a_ligar) printf '%s' "Histórico de uso: o banco (TimescaleDB) chegou depois da configuração deste concentrador. Ligando o histórico agora." ;;
        srv_historico_so_pg_nao_pronto) printf '%s' "O PostgreSQL não ficou pronto a tempo. O histórico de uso segue desligado; tento de novo no próximo arranque." ;;
        srv_historico_so_opcao_falhou) printf '%s' "O banco foi configurado, mas não consegui gravar a opção do histórico em %s. O histórico segue desligado; tento de novo no próximo arranque." ;;
        srv_historico_so_gerencia_nao_reiniciou) printf '%s' "Histórico ligado na configuração, mas não consegui reiniciar o serviço %s. Ele passa a valer quando o serviço for reiniciado." ;;
        # --- reiniciar para a config nova valer ---
        srv_vai_reiniciar)       printf '%s' "O serviço %s já está rodando. Para usar a configuração nova ele será reiniciado, e o vídeo das CPEs para por alguns segundos." ;;
        srv_servico_reiniciado)  printf '%s' "Serviço %s reiniciado: a configuração nova já está valendo." ;;
        srv_config_so_depois_de_reiniciar) printf '%s' "A configuração nova só vale depois de reiniciar o serviço: systemctl restart %s" ;;
        # --- exceção de destino (-destino-permitir) que já estava configurada ---
        srv_destino_permitir_mantido)  printf '%s' "Mantida a exceção de destino que já estava configurada: %s" ;;
        srv_destino_permitir_removido) printf '%s' "A exceção de destino que estava configurada (%s) foi retirada: ela só funciona com mTLS." ;;
        srv_destino_permitir_ilegivel) printf '%s' "Não consegui manter a exceção de destino que estava configurada (%s). Ela fica só na cópia do arquivo anterior; confira e coloque de novo." ;;
        # --- a descarga mensal das bases da DB-IP (avisa_geoip, achado K29) ---
        srv_geoip_aviso)        printf '%s' "Os relatórios vão mostrar nome e lugar de cada destino na internet." ;;
        srv_geoip_baixa)        printf '%s' "Para isso, este servidor baixa todo mês uma base grátis do endereço:" ;;
        srv_geoip_desligar)     printf '%s' "Para não baixar mais, acrescente esta opção às do arquivo abaixo:" ;;
        srv_geoip_bases_ficam)  printf '%s' "Os relatórios continuam usando as bases que já estão neste servidor." ;;
        srv_geoip_sem_bases)    printf '%s' "Este servidor ainda não tem as bases: a primeira vem com a descarga." ;;
        srv_geoip_sem_bases_desligar) printf '%s' "Se desligar antes, os relatórios ficam sem nome e lugar dos destinos." ;;
        srv_geoip_mantida_sem_bases) printf '%s' "Este servidor não tem as bases, e sem a descarga elas não chegam:" ;;
        srv_geoip_sem_nome_lugar) printf '%s' "os relatórios ficam sem nome e sem lugar dos destinos." ;;
        srv_geoip_religar)      printf '%s' "Para tê-las, tire a opção acima e reinicie o serviço." ;;
        srv_geoip_mantida)      printf '%s' "A descarga mensal continua desligada, como já estava:" ;;
        srv_geoip_reiniciar)    printf '%s' "e reinicie o serviço: systemctl restart newbond-gerencia" ;;
        # --- verificar hardware (instalador do CPE, verificar-hardware.sh) ---
        disco_opcao_verificar)  printf '%s' "  0) Verificar o hardware desta máquina (não grava nada)" ;;
        hw_titulo)              printf '%s' "Verificação de hardware" ;;
        hw_nada_gravado)        printf '%s' "Nada é gravado no disco interno." ;;
        hw_tag_ok)              printf '%s' "OK" ;;
        hw_tag_aviso)           printf '%s' "AVISO" ;;
        hw_tag_falta)           printf '%s' "FALTA" ;;
        hw_tag_info)            printf '%s' "INFO" ;;
        hw_dado)                printf '%s' "dado: %s" ;;
        hw_maquina)             printf '%s' "Máquina: %s" ;;
        hw_cpu)                 printf '%s' "Processador: %s" ;;
        hw_cpu_nucleos)         printf '%s' "Núcleos do processador: %s" ;;
        hw_cpu_threads)         printf '%s' "(%s threads)" ;;
        hw_cpu_64_falta)        printf '%s' "O processador não é de 64 bits: o NewBond não roda nele." ;;
        hw_cpu_aes_ok)          printf '%s' "O processador tem AES-NI (criptografia rápida)." ;;
        hw_cpu_aes_falta)       printf '%s' "O processador não tem AES-NI: a criptografia fica lenta." ;;
        hw_cpu_avx2_sim)        printf '%s' "O processador tem AVX2." ;;
        hw_cpu_avx2_nao)        printf '%s' "O processador não tem AVX2 (não impede a instalação)." ;;
        hw_ram)                 printf '%s' "Memória RAM: %s" ;;
        hw_ram_pouca)           printf '%s' "Menos de 4 GB de RAM: abaixo do recomendado." ;;
        hw_disco)               printf '%s' "Disco interno: %s" ;;
        hw_disco_usb)           printf '%s' "Disco USB (não é interno): %s" ;;
        hw_disco_pendrive)      printf '%s' "Pendrive deste instalador: %s" ;;
        hw_disco_nenhum)        printf '%s' "Nenhum disco interno: não há onde instalar." ;;
        hw_disco_pequeno)       printf '%s' "Nenhum disco interno com 4 GB ou mais: o sistema não cabe." ;;
        hw_disco_abaixo)        printf '%s' "O maior disco interno tem menos de 32 GB (recomendado)." ;;
        hw_controladora_sem_driver) printf '%s' "Controladora de disco sem driver: %s" ;;
        hw_rede_cabo_sim)       printf '%s' "Porta de rede %s: cabo conectado" ;;
        hw_rede_cabo_nao)       printf '%s' "Porta de rede %s: sem cabo" ;;
        hw_rede_cabo_desconhecido) printf '%s' "Porta de rede %s: desligada (cabo não verificado)" ;;
        hw_rede_sem_driver)     printf '%s' "Placa de rede sem driver (não reconhecida): %s" ;;
        hw_rede_sem_porta)      printf '%s' "Placa de rede com driver %s, mas a porta não apareceu." ;;
        hw_wifi_sem_driver)     printf '%s' "Placa Wi-Fi sem driver (o NewBond não usa): %s" ;;
        hw_rede_total)          printf '%s' "Portas de rede funcionando: %s" ;;
        hw_rede_nenhuma)        printf '%s' "Nenhuma porta de rede funcionando." ;;
        hw_rede_uma)            printf '%s' "Só 1 porta de rede: a CPE precisa de 2 (WAN e LAN)." ;;
        hw_firmware_falta)      printf '%s' "Falta o firmware %s" ;;
        hw_firmware_falta_ok)   printf '%s' "Falta o firmware %s, mas a placa funcionou." ;;
        hw_firmware_falta_outro) printf '%s' "Falta o firmware %s (não é placa de rede: não impede)." ;;
        hw_firmware_pacote)     printf '%s' "Ele vem no pacote %s: peça ao suporte." ;;
        hw_firmware_nenhum)     printf '%s' "Nenhum firmware em falta." ;;
        hw_usb)                 printf '%s' "Dispositivo USB: %s" ;;
        hw_modem_ok)            printf '%s' "Modem USB pronto: %s" ;;
        hw_modem_sem_interface) printf '%s' "Modem USB sem interface de dados (falta driver): %s" ;;
        hw_modem_modo_disco)    printf '%s' "Modem USB em modo pendrive (precisa modeswitch): %s" ;;
        hw_modem_nenhum)        printf '%s' "Nenhum modem USB encontrado." ;;
        hw_serie)               printf '%s' "Porta serial: %s" ;;
        hw_serie_nenhuma)       printf '%s' "Nenhuma porta serial encontrada." ;;
        hw_arranque_uefi)       printf '%s' "Inicialização (boot) em modo UEFI." ;;
        hw_arranque_bios)       printf '%s' "Inicialização (boot) em modo BIOS (legacy)." ;;
        hw_montagem_alheia)     printf '%s' "%s veio do disco interno (NewBond antigo), não do pendrive." ;;
        hw_resultado_titulo)    printf '%s' "RESULTADO" ;;
        hw_pronto)              printf '%s' "Pronto para instalar." ;;
        hw_pronto_avisos)       printf '%s' "Pronto para instalar, mas leia os itens AVISO." ;;
        hw_nao_pronto)          printf '%s' "Ainda não dá para instalar: veja os itens FALTA." ;;
        hw_dica_suporte)        printf '%s' "Mande o relatório (ou foto da tela) ao suporte." ;;
        hw_salvo)               printf '%s' "Relatório salvo no pendrive, na unidade NEWBOND:" ;;
        hw_salvo_esp)           printf '%s' "Relatório salvo na partição EFI do pendrive (o Windows não mostra):" ;;
        hw_salvo_em)            printf '%s' "Relatório salvo em:" ;;
        hw_salvo_temporario)    printf '%s' "Não deu para salvar no pendrive. Cópia temporária (some ao desligar):" ;;
        hw_enter_voltar)        printf '%s' "Tecle Enter para voltar à lista de discos: " ;;
        hw_enter_continuar)     printf '%s' "Tecle Enter para continuar: " ;;
        instalar_alvo_em_uso)   printf '%s' "O disco %s está em uso por este sistema (montado)." ;;
        instalar_sem_payload)   printf '%s' "O pendrive está incompleto: falta o sistema a gravar." ;;
        instalar_nada_apagado)  printf '%s' "Nada foi apagado. Use a opção 0 e mande o relatório ao suporte." ;;
        hw_ausente)             printf '%s' "A verificação de hardware não está neste pendrive." ;;
        hw_por_falta)           printf '%s' "Vou verificar o hardware para mostrar a causa." ;;
        # --- o produto (cpe | concentrador): texto e limiares do instalador ---
        produto_nome_cpe)            printf '%s' "NewBond CPE" ;;
        produto_nome_concentrador)   printf '%s' "NewBond Concentrador" ;;
        instalar_proximo_concentrador) printf '%s' "No primeiro arranque, ele pedirá a rede e a senha." ;;
        hw_disco_pequeno_conc)  printf '%s' "Nenhum disco interno com 32 GB ou mais: não cabe o concentrador." ;;
        # --- 1.º arranque do concentrador (newbond-primeiro-arranque) ---
        pa_titulo)              printf '%s' "Primeira configuração do NewBond Concentrador" ;;
        pa_passos)              printf '%s' "Passos: 1) rede   2) acesso   3) configuração do NewBond" ;;
        pa_passo_rede)          printf '%s' "Passo 1 de 3: rede" ;;
        pa_passo_acesso)        printf '%s' "Passo 2 de 3: acesso" ;;
        pa_passo_setup)         printf '%s' "Passo 3 de 3: configuração do NewBond" ;;
        pa_ocupada)             printf '%s' "A configuração já está sendo feita em outra tela (%s)." ;;
        pa_ja_concluida)        printf '%s' "A configuração já terminou." ;;
        pa_rede_ja_feita)       printf '%s' "A rede já está configurada. Passando ao próximo passo." ;;
        pa_acesso_ja_feito)     printf '%s' "O acesso já está configurado. Passando ao próximo passo." ;;
        pa_rede_falhou)         printf '%s' "A rede não foi configurada." ;;
        pa_setup_nao_concluiu)  printf '%s' "A configuração do NewBond não foi concluída." ;;
        # Depois de o setup falhar: a rede de agora, e a saída para quem a pôs errada.
        pa_rede_agora)          printf '%s' "Rede agora:" ;;
        pa_rede_endereco)       printf '%s' "Endereço: %s" ;;
        pa_rede_sem_endereco)   printf '%s' "Nenhuma placa tem endereço agora." ;;
        pa_rede_sem_gateway)    printf '%s' "Não há roteador (gateway) configurado." ;;
        pa_rede_gw_ok)          printf '%s' "O roteador %s responde." ;;
        pa_rede_gw_falha)       printf '%s' "O roteador %s NÃO responde." ;;
        pa_setup_dica_rede)     printf '%s' "Se a rede estiver errada, digite R para refazê-la." ;;
        pa_setup_repetir_pergunta) printf '%s' "Enter repete a configuração; R refaz a rede: " ;;
        pa_unbound_falhou)      printf '%s' "Não deu para ligar o unbound. Veja: journalctl -u unbound" ;;
        pa_pronto_titulo)       printf '%s' "Configuração concluída." ;;
        pa_pronto_login)        printf '%s' "Na tela de login, entre como root, com a senha que criou." ;;
        pa_pronto_rede)         printf '%s' "Para mudar a rede depois, rode newbond-rede, ou use o painel." ;;
        pa_instrumento_falta)   printf '%s' "Falta o programa %s nesta máquina. Chame o suporte." ;;
        # --- rede inicial (rede-inicial.sh) ---
        rede_titulo)            printf '%s' "Rede do concentrador" ;;
        rede_intro)             printf '%s' "Escolha a placa de rede e como ela recebe o endereço." ;;
        # ASCII e alinhado com o `printf` do rede-inicial.sh (5 + 12 + 1 + 17 + 1).
        rede_placas_cabecalho)  printf '%s' "  #  PLACA        MAC               ESTADO" ;;
        rede_nenhuma_placa)     printf '%s' "Nenhuma placa de rede foi encontrada." ;;
        rede_placa_pergunta)    printf '%s' "Número da placa: " ;;
        rede_estado_cabo)       printf '%s' "cabo conectado" ;;
        rede_estado_sem_cabo)   printf '%s' "sem cabo" ;;
        rede_estado_desconhecido) printf '%s' "cabo não verificado" ;;
        rede_verificando_cabos) printf '%s' "Verificando os cabos de rede (alguns segundos)..." ;;
        rede_v4_opcoes)         printf '%s' "IPv4:  1) automático (DHCP)   2) endereço fixo" ;;
        rede_v4_pergunta)       printf '%s' "Escolha 1 ou 2 [1]: " ;;
        rede_v4_endereco_pergunta) printf '%s' "Endereço e máscara (ex.: 192.168.0.10/24): " ;;
        rede_v4_gateway_pergunta) printf '%s' "Gateway/roteador (ex.: 192.168.0.1; Enter se não houver): " ;;
        rede_v6_opcoes)         printf '%s' "IPv6:  1) desligado   2) automático (SLAAC)   3) endereço fixo" ;;
        rede_v6_pergunta)       printf '%s' "Escolha 1 a 3 [1]: " ;;
        rede_v6_endereco_pergunta) printf '%s' "Endereço e prefixo (ex.: 2001:db8::10/64): " ;;
        rede_v6_gateway_pergunta) printf '%s' "Gateway IPv6 (Enter se não houver): " ;;
        # O DNS é OPCIONAL: serve de encaminhador do unbound do concentrador, que
        # sem ele resolve sozinho, a partir dos servidores raiz. Duas linhas de
        # explicação (72 colunas) e uma pergunta curta.
        rede_dns_intro1)        printf '%s' "DNS opcional: informe 1 ou 2 servidores, separados por espaço." ;;
        rede_dns_intro2)        printf '%s' "Enter: o concentrador resolve os nomes sozinho (servidores raiz)." ;;
        rede_dns_pergunta)      printf '%s' "Servidor DNS (Enter para pular): " ;;
        rede_dns_pergunta_obrig) printf '%s' "Servidor DNS (1 ou 2, separados por espaço): " ;;
        rede_dns_nenhum)        printf '%s' "nenhum (o concentrador resolve sozinho)" ;;
        rede_dns_pede)          printf '%s' "O DNS local não ligou. Informe um DNS, para não ficar sem." ;;
        rede_dns_reserva)       printf '%s' "Sem o DNS local, a máquina usa o DNS que você informou." ;;
        rede_dns_vazio)         printf '%s' "Informe pelo menos um servidor DNS." ;;
        rede_dns_muitos)        printf '%s' "Informe no máximo 2 servidores DNS." ;;
        rede_dns_invalido)      printf '%s' "O DNS %s não é um endereço válido." ;;
        # O DNS que o unbound recusou (unbound-checkconf), e o teste de resolução.
        rede_dns_nao_serve)     printf '%s' "Esse DNS não serve. Confira os números e digite de novo." ;;
        rede_testando_dns)      printf '%s' "Testando a resolução de nomes..." ;;
        rede_dns_resolve_ok)    printf '%s' "Os nomes de internet estão sendo resolvidos." ;;
        rede_dns_nao_resolve1)  printf '%s' "O concentrador não consegue resolver nomes pela internet." ;;
        rede_dns_nao_resolve2)  printf '%s' "Se o datacenter bloqueia DNS, informe o DNS do datacenter." ;;
        rede_dns_nao_resolve_pergunta) printf '%s' "Enter testa de novo; D informa um DNS; C continua assim: " ;;
        rede_nome_pergunta)     printf '%s' "Nome desta máquina [%s]: " ;;
        rede_nome_invalido)     printf '%s' "Nome inválido: use só letras, números e hífen (até 63)." ;;
        rede_texto_invalido)    printf '%s' "Texto inválido: use só números, letras A-F, '.', ':' e '/'." ;;
        rede_resumo_titulo)     printf '%s' "Confira antes de gravar" ;;
        rede_resumo_placa)      printf '%s' "Placa:  %s" ;;
        rede_resumo_v4)         printf '%s' "IPv4:   %s" ;;
        rede_resumo_v6)         printf '%s' "IPv6:   %s" ;;
        rede_resumo_dns)        printf '%s' "DNS:    %s" ;;
        rede_resumo_nome)       printf '%s' "Nome:   %s" ;;
        rede_modo_dhcp)         printf '%s' "automático (DHCP)" ;;
        rede_modo_slaac)        printf '%s' "automático (SLAAC)" ;;
        rede_modo_nenhum)       printf '%s' "desligado" ;;
        rede_aviso_definitivo)  printf '%s' "Depois de gravada, a rede muda pelo painel ou por newbond-rede." ;;
        rede_confirmar_pergunta) printf '%s' "Gravar esta configuração? [s/N]: " ;;
        rede_cancelado)         printf '%s' "Nada foi gravado. Vamos recomeçar." ;;
        rede_gravando)          printf '%s' "Gravando a rede..." ;;
        rede_gravada)           printf '%s' "Rede gravada." ;;
        rede_recusada)          printf '%s' "A rede não foi gravada. Corrija o que está abaixo:" ;;
        rede_erro_helper)       printf '%s' "Não foi possível gravar a rede: %s" ;;
        rede_ja_configurada)    printf '%s' "Esta máquina já tem a rede configurada. Nada a refazer." ;;
        rede_ligando)           printf '%s' "Ligando o serviço de rede..." ;;
        rede_liga_falhou)       printf '%s' "Não consegui ligar o serviço de rede (systemd-networkd)." ;;
        rede_testando)          printf '%s' "Testando a rede (pode levar alguns segundos)..." ;;
        rede_ok)                printf '%s' "Rede funcionando: o roteador respondeu." ;;
        rede_sem_cabo)          printf '%s' "A placa %s está sem cabo. Conecte o cabo de rede." ;;
        rede_sem_ip)            printf '%s' "A placa não recebeu endereço. Confira o cabo e o DHCP." ;;
        rede_gateway_falhou)    printf '%s' "O roteador %s não respondeu." ;;
        rede_sem_gateway)       printf '%s' "Não há roteador para testar. A rede não foi testada." ;;
        rede_teste_dica1)       printf '%s' "A rede já foi gravada, mas o teste falhou." ;;
        rede_teste_dica2)       printf '%s' "Se o endereço estiver errado, digite R para refazer a rede." ;;
        rede_teste_pergunta)    printf '%s' "Enter testa de novo; R refaz a rede; C continua assim: " ;;
        # --- refazer a rede depois de gravada (rede-inicial.sh --refazer, newbond-rede) ---
        rede_titulo_refazer)    printf '%s' "Refazer a rede do concentrador" ;;
        rede_aviso_refazer)     printf '%s' "Isto muda a rede agora. A ligação remota (SSH) pode cair." ;;
        rede_refazer_virgem)    printf '%s' "A rede ainda não foi configurada: faça o primeiro arranque." ;;
        rede_sem_mudanca)       printf '%s' "A configuração nova é igual à atual. Nada mudou." ;;
        rede_placa_fica)        printf '%s' "A placa %s continua configurada como estava." ;;
        rede_refazer_fica1)     printf '%s' "Só o IPv4 e o IPv6 da placa escolhida mudam." ;;
        rede_refazer_fica2)     printf '%s' "VLANs, rotas e as outras placas ficam como estão." ;;
        nr_remoto)              printf '%s' "Pelo acesso remoto, mude a rede pelo painel, que tem o modo seguro." ;;
        nr_precisa_root)        printf '%s' "Este comando precisa rodar como root, na consola local." ;;
        nr_atual)               printf '%s' "Rede atual desta máquina:" ;;
        nr_aviso)               printf '%s' "A ligação remota (SSH) pode cair ao mudar a rede." ;;
        nr_confirmar)           printf '%s' "Continuar? [s/N]: " ;;
        nr_cancelado)           printf '%s' "Nada foi mudado." ;;
        # --- acesso (senha local e chave SSH) ---
        acesso_senha_intro1)    printf '%s' "Crie a senha para entrar nesta máquina por esta tela." ;;
        acesso_senha_intro2)    printf '%s' "O usuário é root. Use letras sem acento, números e símbolos." ;;
        acesso_senha_pergunta)  printf '%s' "Nova senha: " ;;
        acesso_senha_repita)    printf '%s' "Repita a senha: " ;;
        acesso_senha_curta)     printf '%s' "A senha precisa ter pelo menos %s caracteres." ;;
        acesso_senha_ascii)     printf '%s' "Use só letras sem acento, números e símbolos comuns." ;;
        acesso_senha_diferente) printf '%s' "As senhas não são iguais. Tente de novo." ;;
        acesso_senha_falhou)    printf '%s' "Não consegui gravar a senha. Tente de novo." ;;
        acesso_senha_ok)        printf '%s' "Senha gravada." ;;
        acesso_chave_intro1)    printf '%s' "Para entrar também por SSH, cole aqui a sua chave pública." ;;
        acesso_chave_intro2)    printf '%s' "É uma linha só, que começa com ssh-ed25519 ou ssh-rsa." ;;
        acesso_chave_intro3)    printf '%s' "Para pular, aperte Enter: ninguém entra por SSH." ;;
        acesso_chave_pergunta)  printf '%s' "Chave pública (Enter para pular): " ;;
        acesso_chave_invalida)  printf '%s' "Isso não parece uma chave pública. Tente de novo." ;;
        acesso_chave_ok)        printf '%s' "Chave aceita (%s)." ;;
        acesso_chave_falhou)    printf '%s' "Não consegui guardar a chave." ;;
        acesso_sem_chave1)      printf '%s' "Sem chave, o SSH fica sem como entrar." ;;
        acesso_sem_chave2)      printf '%s' "A entrada será só por esta tela, com a senha." ;;
        *)                    printf '%s' "" ;;
    esac
}

# ---------------------------------------------------------------------------
# en-US -- idioma de arranque do instalador
# ---------------------------------------------------------------------------
_msg_en_us() {
    case "$1" in
        menu_idioma_titulo)   printf '%s' "NewBond Installer" ;;
        menu_idioma_opcoes)   printf '%s' "1) Portugues (Brasil)  2) English (US)  3) Espanol" ;;
        menu_idioma_pergunta) printf '%s' "Choose 1-3 [2]: " ;;
        disco_titulo)         printf '%s' "Select the installation disk" ;;
        disco_cabecalho)      printf '%s' "  #  DEVICE           SIZE      MODEL" ;;
        disco_nenhum)         printf '%s' "No internal disk was found." ;;
        disco_pergunta)       printf '%s' "Disk number: " ;;
        disco_invalido)       printf '%s' "Number not in the list. Try again." ;;
        apagar_aviso)         printf '%s' "WARNING: all content on disk %s will be ERASED." ;;
        apagar_pergunta)      printf '%s' "Type %s to confirm: " ;;
        apagar_recusado)      printf '%s' "Word did not match. Nothing was erased." ;;
        instalar_a_escrever)  printf '%s' "Writing the system to disk. DO NOT power off." ;;
        instalar_pronto)      printf '%s' "Install complete." ;;
        instalar_falhou)      printf '%s' "Install failed: %s" ;;
        simulacao_aviso)      printf '%s' "SIMULATION MODE: nothing will be written to disk." ;;
        # --- two screens at once (monitor and serial port) ---
        consola_ocupada)       printf '%s' "The installation is already running on another screen (%s)." ;;
        consola_ocupada_dica)  printf '%s' "Use that screen, or wait for it to finish." ;;
        consola_monitor)       printf '%s' "monitor and keyboard" ;;
        consola_serie)         printf '%s' "serial port" ;;
        instalar_ja_concluida) printf '%s' "The installation is already done." ;;
        tecla_enter_voltar)    printf '%s' "Press Enter to go back: " ;;
        tecla_enter_recomecar) printf '%s' "Press Enter to start over: " ;;
        # --- the end: power off BEFORE removing the USB drive (root lives on it) ---
        instalar_depois_desligar) printf '%s' "When the device is off, remove the USB drive and turn it on again." ;;
        tecla_enter_desligar)     printf '%s' "Press Enter to turn the device off: " ;;
        instalar_desligando)      printf '%s' "Turning off... When the screen goes dark, remove the USB drive." ;;
        # --- one screen takes over the installation stopped on the other ---
        consola_assumir_dica)     printf '%s' "If nobody is using that screen, type %s to use this one." ;;
        consola_ocupada_gravando) printf '%s' "That screen is already writing the disk. Wait for it to finish." ;;
        consola_assumir_recusado) printf '%s' "Cannot take over: the other screen is already writing the disk." ;;
        consola_assumir_falhou)   printf '%s' "Could not take over the installation. Try again." ;;
        consola_assumida)         printf '%s' "Another screen took over the installation. Nothing was erased." ;;
        # --- newbond-server-setup (concentrator), not the CPE installer ---
        srv_titulo)            printf '%s' "NewBond concentrator first-time setup" ;;
        srv_precisa_root)     printf '%s' "This wizard must run as root." ;;
        srv_ja_configurado)   printf '%s' "Config already exists at %s; will be replaced (backup kept)." ;;
        srv_listen_pergunta)  printf '%s' "Listen address (e.g. :5001): " ;;
        srv_mtls_titulo)      printf '%s' "mTLS configuration" ;;
        srv_mtls_opcao_auto)     printf '%s' "1) Automatic (recommended): the concentrator creates its own certificate authority, and CPEs are authorized from the management screen" ;;
        srv_mtls_opcao_arquivos) printf '%s' "2) mTLS with my own files (I already have certificate, key and CA)" ;;
        srv_mtls_opcao_bancada)  printf '%s' "3) generate a BENCH set" ;;
        srv_mtls_opcao_semtls)   printf '%s' "4) no mTLS (not recommended)" ;;
        srv_mtls_pergunta)    printf '%s' "Choose 1-4: " ;;
        srv_cert_pergunta)    printf '%s' "Path to this server's certificate: " ;;
        srv_chave_pergunta)   printf '%s' "Path to the private key: " ;;
        srv_ca_pergunta)      printf '%s' "Path to the CA that signs the CPEs: " ;;
        srv_ficheiro_falta)   printf '%s' "Does not exist or cannot be read: %s" ;;
        srv_bancada_aviso)    printf '%s' "WARNING: BENCH-only material, not for production." ;;
        srv_sem_mtls_aviso)   printf '%s' "WARNING: no mTLS; section 6.1 requires it." ;;
        srv_cpes_pergunta)    printf '%s' "Path to the admitted CPE list (empty = none): " ;;
        srv_resumo_titulo)    printf '%s' "Summary of what will be written" ;;
        srv_confirmar)        printf '%s' "Confirm and write? [y/N]: " ;;
        srv_cancelado)        printf '%s' "Nothing was written." ;;
        srv_escrito)          printf '%s' "Configuration written to %s" ;;
        srv_copia)            printf '%s' "The previous one was saved at %s" ;;
        srv_activar_pergunta) printf '%s' "Activate and start the service now? [y/N]: " ;;
        srv_activado)         printf '%s' "Service activated." ;;
        srv_nao_activado)     printf '%s' "Service NOT activated; command to activate later:" ;;
        srv_auto_titulo)               printf '%s' "Automatic mode — the concentrator's own CA" ;;
        srv_auto_papel_opcao_principal) printf '%s' "1) Primary (recommended): this concentrator holds the certificate authority and approves CPEs" ;;
        srv_auto_papel_opcao_reserva)   printf '%s' "2) Backup: takes over if the primary concentrator goes down; an administrator approves this concentrator on the primary" ;;
        srv_auto_papel_pergunta)        printf '%s' "Choose 1-2 [1]: " ;;
        srv_auto_enderecos_pergunta)   printf '%s' "Concentrator's public address (name or IP; more than one, comma-separated): " ;;
        srv_auto_enderecos_vazio)      printf '%s' "At least one public address is required: it's what the CPEs will use to reach the concentrator." ;;
        srv_auto_a_activar_gerencia)   printf '%s' "Activating management and waiting for the certificate authority..." ;;
        srv_auto_gerencia_falhou_activar) printf '%s' "Could not activate newbond-gerencia." ;;
        srv_auto_ca_nao_apareceu)      printf '%s' "The certificate authority did not appear within %s. newbond-server was NOT activated." ;;
        srv_auto_ca_pronta)            printf '%s' "Certificate authority ready." ;;
        srv_auto_journal_titulo)       printf '%s' "Last lines from the newbond-gerencia service:" ;;
        srv_auto_server_falhou_activar) printf '%s' "newbond-gerencia is ready, but I could not activate newbond-server." ;;
        srv_auto_resumo_titulo)        printf '%s' "Done! The concentrator is up." ;;
        srv_auto_painel_linha)         printf '%s' "Administrator panel: %s (on first access it will ask you to create the administrator password)" ;;
        srv_auto_firewall_titulo)      printf '%s' "Ports to open on the datacenter firewall:" ;;
        srv_auto_porta_video)             printf '%s' "%s/tcp — CPE video" ;;
        srv_auto_porta_gerencia)          printf '%s' "5003/tcp — CPE management" ;;
        srv_auto_porta_adesao)            printf '%s' "5005/tcp — new CPE enrollment" ;;
        srv_auto_porta_tunel)             printf '%s' "51820/udp — remote access (tunnel)" ;;
        srv_auto_porta_abrir_painel)      printf '%s' "8444/tcp — open CPE panels" ;;
        srv_auto_porta_painel_operadores) printf '%s' "8443/tcp — operator panel (recommended to expose only on the management network/VPN)" ;;
        srv_auto_porta_redir)             printf '%s' "%s/tcp — open ports (CPE connections for port forwarding)" ;;
        srv_auto_porta_redir_regras)      printf '%s' "and each port you open in 'Open ports on the concentrator', on the panel (only the sources you allow can use it)" ;;
        srv_auto_redir_falhou_activar)    printf '%s' "Video is on the air, but I could not activate newbond-redir (open ports). See: journalctl -u newbond-redir" ;;
        srv_redir_endereco_privado)       printf '%s' "The address %s belongs to an internal network and cannot be reached from outside: it was not used as the public address for open ports. The «Open ports on the concentrator» screen will ask the operator to confirm the address with support. To fix it, run this wizard again and include the public IPv4 of the concentrator in the list." ;;
        # --- backup concentrator (ADR 0138 §3, A3.2) ---
        srv_auto_reserva_titulo)             printf '%s' "Automatic mode — backup concentrator" ;;
        srv_auto_reserva_principal_pergunta) printf '%s' "Address (name or IP) of the primary concentrator: " ;;
        srv_auto_reserva_principal_vazio)    printf '%s' "The primary concentrator's address is required." ;;
        srv_auto_reserva_enderecos_pergunta) printf '%s' "This backup concentrator's public address (name or IP; more than one, comma-separated): " ;;
        srv_auto_reserva_codigo_titulo)      printf '%s' "Pairing code" ;;
        srv_auto_reserva_instrucao)          printf '%s' "On the primary concentrator's panel, approve this backup concentrator's request by checking the code %s" ;;
        srv_auto_reserva_codigo_nao_apareceu) printf '%s' "Could not get a pairing code from the primary concentrator. Check the address and the invitation code: an invitation is valid for 24 hours and only once. If needed, create another one on the primary's panel and run this wizard again." ;;
        # --- pairing invitation (contract of 2026-10-01, part D) ---
        srv_auto_reserva_convite_pergunta)   printf '%s' "Invitation code created on the primary concentrator's panel (e.g. ABCD-EFGH-JKMN): " ;;
        srv_auto_reserva_convite_invalido)   printf '%s' "That code is not in the right format: it has 12 letters and digits, like ABCD-EFGH-JKMN (the letters I, L, O and U are never used). Check it and type it again." ;;
        srv_auto_reserva_convite_desistiu)   printf '%s' "Pairing needs a valid invitation code. Create an invitation on the primary concentrator's panel and run this wizard again." ;;
        srv_auto_reserva_convite_ja_pareada) printf '%s' "This backup concentrator is already paired: leave the invitation code blank to keep it as it is." ;;
        srv_auto_reserva_convite_revogada)   printf '%s' "This concentrator was removed by the primary concentrator. To use it as a backup again, create an invitation on the primary and enter it here." ;;
        srv_auto_reserva_convite_guardado_pareada) printf '%s' "This concentrator is already paired: the code was saved and will only be used if the primary concentrator removes it." ;;
        srv_auto_reserva_convite_recusado)   printf '%s' "The primary concentrator refused the invitation code: it does not exist, was already used or expired (valid for 24 hours). Create another one on the primary's panel and run this wizard again." ;;
        srv_auto_reserva_convite_resumo)     printf '%s' "Invitation code: will be saved in %s (not shown here)" ;;
        srv_auto_reserva_convite_gravado)    printf '%s' "Invitation code saved in %s." ;;
        srv_auto_reserva_convite_nao_gravou) printf '%s' "Could not save the invitation code in %s. Nothing was activated." ;;
        srv_auto_reserva_nao_aprovado)       printf '%s' "Nobody approved this backup concentrator in time. newbond-server was NOT activated." ;;
        srv_auto_reserva_tente_de_novo)      printf '%s' "Management is still active, waiting for approval. As soon as someone approves it on the primary, run this wizard again to finish." ;;
        srv_auto_reserva_resumo_titulo)      printf '%s' "Done! This backup concentrator is paired." ;;
        # --- usage history (ADR 0140, slice H4) ---
        srv_historico_desligado) printf '%s' "Usage history disabled: the database (TimescaleDB) is not installed. The concentrator works without it; to enable it, install the package and run this wizard again." ;;
        srv_historico_ligado)    printf '%s' "Usage history enabled (TimescaleDB)." ;;
        srv_historico_simulado)  printf '%s' "Usage history: under --raiz, nothing runs on PostgreSQL (would restart the service and create the newbond role/database)." ;;
        srv_historico_falhou)    printf '%s' "Could not configure usage history (%s). History stays disabled; check: journalctl -u postgresql" ;;
        # --- history enabled after an update (newbond-server-setup --so-historico) ---
        srv_historico_so_a_ligar) printf '%s' "Usage history: the database (TimescaleDB) arrived after this concentrator was configured. Enabling history now." ;;
        srv_historico_so_pg_nao_pronto) printf '%s' "PostgreSQL was not ready in time. Usage history stays disabled; I will try again at the next boot." ;;
        srv_historico_so_opcao_falhou) printf '%s' "The database was configured, but I could not write the history option to %s. History stays disabled; I will try again at the next boot." ;;
        srv_historico_so_gerencia_nao_reiniciou) printf '%s' "History enabled in the configuration, but I could not restart the %s service. It takes effect when the service is restarted." ;;
        # --- restart so the new config takes effect ---
        srv_vai_reiniciar)       printf '%s' "The %s service is already running. It will be restarted to use the new configuration, and video from the CPEs stops for a few seconds." ;;
        srv_servico_reiniciado)  printf '%s' "Service %s restarted: the new configuration is now in effect." ;;
        srv_config_so_depois_de_reiniciar) printf '%s' "The new configuration only takes effect after restarting the service: systemctl restart %s" ;;
        # --- destination exception (-destino-permitir) already configured ---
        srv_destino_permitir_mantido)  printf '%s' "Kept the destination exception that was already configured: %s" ;;
        srv_destino_permitir_removido) printf '%s' "The destination exception that was configured (%s) was removed: it only works with mTLS." ;;
        srv_destino_permitir_ilegivel) printf '%s' "Could not keep the destination exception that was configured (%s). It stays only in the backup of the previous file; check it and add it again." ;;
        # --- the monthly download of the DB-IP databases (avisa_geoip, finding K29) ---
        srv_geoip_aviso)        printf '%s' "Reports will show the name and location of each internet destination." ;;
        srv_geoip_baixa)        printf '%s' "For that, this server downloads a free database every month from:" ;;
        srv_geoip_desligar)     printf '%s' "To stop downloading, add this option to the ones in the file below:" ;;
        srv_geoip_bases_ficam)  printf '%s' "Reports keep using the databases already on this server." ;;
        srv_geoip_sem_bases)    printf '%s' "This server does not have these databases yet: the download brings them." ;;
        srv_geoip_sem_bases_desligar) printf '%s' "Turn it off before that and reports show no destination name or place." ;;
        srv_geoip_mantida_sem_bases) printf '%s' "This server has no databases; with the download off they never arrive:" ;;
        srv_geoip_sem_nome_lugar) printf '%s' "reports show no name and no place for destinations." ;;
        srv_geoip_religar)      printf '%s' "To get them, remove the option above and restart the service." ;;
        srv_geoip_mantida)      printf '%s' "The monthly download stays off, as it was:" ;;
        srv_geoip_reiniciar)    printf '%s' "and restart the service: systemctl restart newbond-gerencia" ;;
        # --- hardware check (CPE installer, verificar-hardware.sh) ---
        disco_opcao_verificar)  printf '%s' "  0) Check this machine's hardware (writes nothing)" ;;
        hw_titulo)              printf '%s' "Hardware check" ;;
        hw_nada_gravado)        printf '%s' "Nothing is written to the internal disk." ;;
        hw_tag_ok)              printf '%s' "OK" ;;
        hw_tag_aviso)           printf '%s' "WARNING" ;;
        hw_tag_falta)           printf '%s' "MISSING" ;;
        hw_tag_info)            printf '%s' "INFO" ;;
        hw_dado)                printf '%s' "data: %s" ;;
        hw_maquina)             printf '%s' "Machine: %s" ;;
        hw_cpu)                 printf '%s' "Processor: %s" ;;
        hw_cpu_nucleos)         printf '%s' "Processor cores: %s" ;;
        hw_cpu_threads)         printf '%s' "(%s threads)" ;;
        hw_cpu_64_falta)        printf '%s' "The processor is not 64-bit: NewBond does not run on it." ;;
        hw_cpu_aes_ok)          printf '%s' "The processor has AES-NI (fast encryption)." ;;
        hw_cpu_aes_falta)       printf '%s' "The processor has no AES-NI: encryption will be slow." ;;
        hw_cpu_avx2_sim)        printf '%s' "The processor has AVX2." ;;
        hw_cpu_avx2_nao)        printf '%s' "The processor has no AVX2 (does not block the install)." ;;
        hw_ram)                 printf '%s' "RAM: %s" ;;
        hw_ram_pouca)           printf '%s' "Less than 4 GB of RAM: below the recommended." ;;
        hw_disco)               printf '%s' "Internal disk: %s" ;;
        hw_disco_usb)           printf '%s' "USB disk (not internal): %s" ;;
        hw_disco_pendrive)      printf '%s' "This installer's USB drive: %s" ;;
        hw_disco_nenhum)        printf '%s' "No internal disk: there is nowhere to install." ;;
        hw_disco_pequeno)       printf '%s' "No internal disk of 4 GB or more: the system does not fit." ;;
        hw_disco_abaixo)        printf '%s' "The largest internal disk is under 32 GB (recommended)." ;;
        hw_controladora_sem_driver) printf '%s' "Disk controller without a driver: %s" ;;
        hw_rede_cabo_sim)       printf '%s' "Network port %s: cable connected" ;;
        hw_rede_cabo_nao)       printf '%s' "Network port %s: no cable" ;;
        hw_rede_cabo_desconhecido) printf '%s' "Network port %s: down (cable not checked)" ;;
        hw_rede_sem_driver)     printf '%s' "Network card without a driver (not recognized): %s" ;;
        hw_rede_sem_porta)      printf '%s' "Network card with driver %s, but the port did not appear." ;;
        hw_wifi_sem_driver)     printf '%s' "Wi-Fi card without a driver (NewBond does not use it): %s" ;;
        hw_rede_total)          printf '%s' "Working network ports: %s" ;;
        hw_rede_nenhuma)        printf '%s' "No working network port." ;;
        hw_rede_uma)            printf '%s' "Only 1 network port: the CPE needs 2 (WAN and LAN)." ;;
        hw_firmware_falta)      printf '%s' "Missing firmware %s" ;;
        hw_firmware_falta_ok)   printf '%s' "Missing firmware %s, but the card works." ;;
        hw_firmware_falta_outro) printf '%s' "Missing firmware %s (not a network card: does not block)." ;;
        hw_firmware_pacote)     printf '%s' "It comes in package %s: ask support." ;;
        hw_firmware_nenhum)     printf '%s' "No missing firmware." ;;
        hw_usb)                 printf '%s' "USB device: %s" ;;
        hw_modem_ok)            printf '%s' "USB modem ready: %s" ;;
        hw_modem_sem_interface) printf '%s' "USB modem without a data interface (no driver): %s" ;;
        hw_modem_modo_disco)    printf '%s' "USB modem in storage mode (needs modeswitch): %s" ;;
        hw_modem_nenhum)        printf '%s' "No USB modem found." ;;
        hw_serie)               printf '%s' "Serial port: %s" ;;
        hw_serie_nenhuma)       printf '%s' "No serial port found." ;;
        hw_arranque_uefi)       printf '%s' "Booted in UEFI mode." ;;
        hw_arranque_bios)       printf '%s' "Booted in BIOS (legacy) mode." ;;
        hw_montagem_alheia)     printf '%s' "%s came from the internal disk (old NewBond), not the USB drive." ;;
        hw_resultado_titulo)    printf '%s' "RESULT" ;;
        hw_pronto)              printf '%s' "Ready to install." ;;
        hw_pronto_avisos)       printf '%s' "Ready to install, but read the WARNING items." ;;
        hw_nao_pronto)          printf '%s' "Not ready to install yet: see the MISSING items." ;;
        hw_dica_suporte)        printf '%s' "Send the report (or a photo of the screen) to support." ;;
        hw_salvo)               printf '%s' "Report saved on the USB drive, in the NEWBOND volume:" ;;
        hw_salvo_esp)           printf '%s' "Report saved in the USB drive's EFI partition (hidden in Windows):" ;;
        hw_salvo_em)            printf '%s' "Report saved in:" ;;
        hw_salvo_temporario)    printf '%s' "Could not save to the USB drive. Temporary copy (lost at power off):" ;;
        hw_enter_voltar)        printf '%s' "Press Enter to go back to the disk list: " ;;
        hw_enter_continuar)     printf '%s' "Press Enter to continue: " ;;
        instalar_alvo_em_uso)   printf '%s' "Disk %s is in use by this system (mounted)." ;;
        instalar_sem_payload)   printf '%s' "The USB drive is incomplete: the system to write is missing." ;;
        instalar_nada_apagado)  printf '%s' "Nothing was erased. Use option 0 and send the report to support." ;;
        hw_ausente)             printf '%s' "The hardware check is not on this USB drive." ;;
        hw_por_falta)           printf '%s' "Checking the hardware to show the cause." ;;
        # --- the product (cpe | concentrador): installer text and thresholds ---
        produto_nome_cpe)            printf '%s' "NewBond CPE" ;;
        produto_nome_concentrador)   printf '%s' "NewBond Concentrador" ;;
        instalar_proximo_concentrador) printf '%s' "On first boot, it will ask for the network and a password." ;;
        hw_disco_pequeno_conc)  printf '%s' "No internal disk of 32 GB or more: the concentrator won't fit." ;;
        # --- concentrator first boot (newbond-primeiro-arranque) ---
        pa_titulo)              printf '%s' "NewBond Concentrador - first-time setup" ;;
        pa_passos)              printf '%s' "Steps: 1) network   2) access   3) NewBond setup" ;;
        pa_passo_rede)          printf '%s' "Step 1 of 3: network" ;;
        pa_passo_acesso)        printf '%s' "Step 2 of 3: access" ;;
        pa_passo_setup)         printf '%s' "Step 3 of 3: NewBond setup" ;;
        pa_ocupada)             printf '%s' "The setup is already being done on another screen (%s)." ;;
        pa_ja_concluida)        printf '%s' "The setup is already done." ;;
        pa_rede_ja_feita)       printf '%s' "The network is already set up. Moving on to the next step." ;;
        pa_acesso_ja_feito)     printf '%s' "Access is already set up. Moving on to the next step." ;;
        pa_rede_falhou)         printf '%s' "The network was not set up." ;;
        pa_setup_nao_concluiu)  printf '%s' "The NewBond setup was not completed." ;;
        pa_rede_agora)          printf '%s' "Network now:" ;;
        pa_rede_endereco)       printf '%s' "Address: %s" ;;
        pa_rede_sem_endereco)   printf '%s' "No card has an address now." ;;
        pa_rede_sem_gateway)    printf '%s' "No router (gateway) is configured." ;;
        pa_rede_gw_ok)          printf '%s' "The router %s answers." ;;
        pa_rede_gw_falha)       printf '%s' "The router %s does NOT answer." ;;
        pa_setup_dica_rede)     printf '%s' "If the network is wrong, type R to redo it." ;;
        pa_setup_repetir_pergunta) printf '%s' "Enter repeats the setup; R redoes the network: " ;;
        pa_unbound_falhou)      printf '%s' "Could not start unbound. See: journalctl -u unbound" ;;
        pa_pronto_titulo)       printf '%s' "Setup complete." ;;
        pa_pronto_login)        printf '%s' "At the login screen, sign in as root with the password you set." ;;
        pa_pronto_rede)         printf '%s' "To change the network later, run newbond-rede, or use the panel." ;;
        pa_instrumento_falta)   printf '%s' "The program %s is missing on this machine. Call support." ;;
        # --- initial network (rede-inicial.sh) ---
        rede_titulo)            printf '%s' "Concentrator network" ;;
        rede_intro)             printf '%s' "Choose the network card and how it gets its address." ;;
        rede_placas_cabecalho)  printf '%s' "  #  CARD         MAC               STATE" ;;
        rede_nenhuma_placa)     printf '%s' "No network card was found." ;;
        rede_placa_pergunta)    printf '%s' "Card number: " ;;
        rede_estado_cabo)       printf '%s' "cable connected" ;;
        rede_estado_sem_cabo)   printf '%s' "no cable" ;;
        rede_estado_desconhecido) printf '%s' "cable not checked" ;;
        rede_verificando_cabos) printf '%s' "Checking the network cables (a few seconds)..." ;;
        rede_v4_opcoes)         printf '%s' "IPv4:  1) automatic (DHCP)   2) fixed address" ;;
        rede_v4_pergunta)       printf '%s' "Choose 1 or 2 [1]: " ;;
        rede_v4_endereco_pergunta) printf '%s' "Address and mask (e.g. 192.168.0.10/24): " ;;
        rede_v4_gateway_pergunta) printf '%s' "Gateway/router (e.g. 192.168.0.1; Enter if none): " ;;
        rede_v6_opcoes)         printf '%s' "IPv6:  1) off   2) automatic (SLAAC)   3) fixed address" ;;
        rede_v6_pergunta)       printf '%s' "Choose 1 to 3 [1]: " ;;
        rede_v6_endereco_pergunta) printf '%s' "Address and prefix (e.g. 2001:db8::10/64): " ;;
        rede_v6_gateway_pergunta) printf '%s' "IPv6 gateway (Enter if none): " ;;
        # The DNS is OPTIONAL: it only forwards for the concentrator's own unbound,
        # which without it resolves by itself, from the root servers.
        rede_dns_intro1)        printf '%s' "Optional DNS: enter 1 or 2 servers, separated by space." ;;
        rede_dns_intro2)        printf '%s' "Enter: the concentrator resolves names by itself (root servers)." ;;
        rede_dns_pergunta)      printf '%s' "DNS server (Enter to skip): " ;;
        rede_dns_pergunta_obrig) printf '%s' "DNS server (1 or 2, separated by space): " ;;
        rede_dns_nenhum)        printf '%s' "none (the concentrator resolves by itself)" ;;
        rede_dns_pede)          printf '%s' "Local DNS did not start. Enter a DNS server to avoid having none." ;;
        rede_dns_reserva)       printf '%s' "Without local DNS, the machine uses the DNS you entered." ;;
        rede_dns_vazio)         printf '%s' "Enter at least one DNS server." ;;
        rede_dns_muitos)        printf '%s' "Enter at most 2 DNS servers." ;;
        rede_dns_invalido)      printf '%s' "The DNS %s is not a valid address." ;;
        rede_dns_nao_serve)     printf '%s' "That DNS does not work. Check the numbers and type it again." ;;
        rede_testando_dns)      printf '%s' "Testing name resolution..." ;;
        rede_dns_resolve_ok)    printf '%s' "Internet names are being resolved." ;;
        rede_dns_nao_resolve1)  printf '%s' "The concentrator cannot resolve names over the internet." ;;
        rede_dns_nao_resolve2)  printf '%s' "If the datacenter blocks DNS, enter the datacenter's DNS." ;;
        rede_dns_nao_resolve_pergunta) printf '%s' "Enter tests again; D enters a DNS; C continues anyway: " ;;
        rede_nome_pergunta)     printf '%s' "Name of this machine [%s]: " ;;
        rede_nome_invalido)     printf '%s' "Invalid name: use only letters, numbers and hyphen (up to 63)." ;;
        rede_texto_invalido)    printf '%s' "Invalid text: use only numbers, letters A-F, '.', ':' and '/'." ;;
        rede_resumo_titulo)     printf '%s' "Check before saving" ;;
        rede_resumo_placa)      printf '%s' "Card:   %s" ;;
        rede_resumo_v4)         printf '%s' "IPv4:   %s" ;;
        rede_resumo_v6)         printf '%s' "IPv6:   %s" ;;
        rede_resumo_dns)        printf '%s' "DNS:    %s" ;;
        rede_resumo_nome)       printf '%s' "Name:   %s" ;;
        rede_modo_dhcp)         printf '%s' "automatic (DHCP)" ;;
        rede_modo_slaac)        printf '%s' "automatic (SLAAC)" ;;
        rede_modo_nenhum)       printf '%s' "off" ;;
        rede_aviso_definitivo)  printf '%s' "Once saved, the network changes in the panel or with newbond-rede." ;;
        rede_confirmar_pergunta) printf '%s' "Save this setup? [y/N]: " ;;
        rede_cancelado)         printf '%s' "Nothing was saved. Let's start again." ;;
        rede_gravando)          printf '%s' "Saving the network..." ;;
        rede_gravada)           printf '%s' "Network saved." ;;
        rede_recusada)          printf '%s' "The network was not saved. Fix what is listed below:" ;;
        rede_erro_helper)       printf '%s' "Could not save the network: %s" ;;
        rede_ja_configurada)    printf '%s' "This machine already has its network set up. Nothing to redo." ;;
        rede_ligando)           printf '%s' "Starting the network service..." ;;
        rede_liga_falhou)       printf '%s' "Could not start the network service (systemd-networkd)." ;;
        rede_testando)          printf '%s' "Testing the network (may take a few seconds)..." ;;
        rede_ok)                printf '%s' "Network working: the router answered." ;;
        rede_sem_cabo)          printf '%s' "Card %s has no cable. Plug in the network cable." ;;
        rede_sem_ip)            printf '%s' "The card got no address. Check the cable and the DHCP." ;;
        rede_gateway_falhou)    printf '%s' "The router %s did not answer." ;;
        rede_sem_gateway)       printf '%s' "No router to test. The network was not tested." ;;
        rede_teste_dica1)       printf '%s' "The network is already saved, but the test failed." ;;
        rede_teste_dica2)       printf '%s' "If the address is wrong, type R to redo the network." ;;
        rede_teste_pergunta)    printf '%s' "Enter tests again; R redoes the network; C continues anyway: " ;;
        # --- redoing the network after it was saved (rede-inicial.sh --refazer, newbond-rede) ---
        rede_titulo_refazer)    printf '%s' "Redo the concentrator network" ;;
        rede_aviso_refazer)     printf '%s' "This changes the network now. A remote (SSH) link may drop." ;;
        rede_refazer_virgem)    printf '%s' "The network is not set up yet: finish the first-boot setup." ;;
        rede_sem_mudanca)       printf '%s' "The new setup is the same as the current one. Nothing changed." ;;
        rede_placa_fica)        printf '%s' "Card %s stays configured as it was." ;;
        rede_refazer_fica1)     printf '%s' "Only the chosen card's IPv4 and IPv6 change." ;;
        rede_refazer_fica2)     printf '%s' "VLANs, routes and the other cards stay as they are." ;;
        nr_remoto)              printf '%s' "Over remote access, change the network in the panel (safe mode)." ;;
        nr_precisa_root)        printf '%s' "This command must run as root, on the local console." ;;
        nr_atual)               printf '%s' "Current network of this machine:" ;;
        nr_aviso)               printf '%s' "A remote (SSH) link may drop when the network changes." ;;
        nr_confirmar)           printf '%s' "Continue? [y/N]: " ;;
        nr_cancelado)           printf '%s' "Nothing was changed." ;;
        # --- access (local password and SSH key) ---
        acesso_senha_intro1)    printf '%s' "Create the password to sign in to this machine on this screen." ;;
        acesso_senha_intro2)    printf '%s' "The user is root. Use letters without accents, numbers, symbols." ;;
        acesso_senha_pergunta)  printf '%s' "New password: " ;;
        acesso_senha_repita)    printf '%s' "Repeat the password: " ;;
        acesso_senha_curta)     printf '%s' "The password must have at least %s characters." ;;
        acesso_senha_ascii)     printf '%s' "Use only letters without accents, numbers and common symbols." ;;
        acesso_senha_diferente) printf '%s' "The passwords do not match. Try again." ;;
        acesso_senha_falhou)    printf '%s' "Could not save the password. Try again." ;;
        acesso_senha_ok)        printf '%s' "Password saved." ;;
        acesso_chave_intro1)    printf '%s' "To also sign in by SSH, paste your public key here." ;;
        acesso_chave_intro2)    printf '%s' "It is one line, starting with ssh-ed25519 or ssh-rsa." ;;
        acesso_chave_intro3)    printf '%s' "To skip, press Enter: nobody will sign in by SSH." ;;
        acesso_chave_pergunta)  printf '%s' "Public key (Enter to skip): " ;;
        acesso_chave_invalida)  printf '%s' "That does not look like a public key. Try again." ;;
        acesso_chave_ok)        printf '%s' "Key accepted (%s)." ;;
        acesso_chave_falhou)    printf '%s' "Could not save the key." ;;
        acesso_sem_chave1)      printf '%s' "Without a key, SSH has no way to sign in." ;;
        acesso_sem_chave2)      printf '%s' "Sign-in will be only on this screen, with the password." ;;
        *)                    printf '%s' "" ;;
    esac
}

# ---------------------------------------------------------------------------
# es
# ---------------------------------------------------------------------------
_msg_es() {
    case "$1" in
        menu_idioma_titulo)   printf '%s' "Instalador NewBond" ;;
        menu_idioma_opcoes)   printf '%s' "1) Portugues (Brasil)  2) English (US)  3) Espanol" ;;
        menu_idioma_pergunta) printf '%s' "Elija 1-3 [2]: " ;;
        disco_titulo)         printf '%s' "Selección del disco de instalación" ;;
        disco_cabecalho)      printf '%s' "  #  DISPOSITIVO      TAMANO    MODELO" ;;
        disco_nenhum)         printf '%s' "No se encontró ningún disco interno." ;;
        disco_pergunta)       printf '%s' "Número de disco: " ;;
        disco_invalido)       printf '%s' "Número fuera de la lista. Intente de nuevo." ;;
        apagar_aviso)         printf '%s' "AVISO: todo el contenido del disco %s será BORRADO." ;;
        apagar_pergunta)      printf '%s' "Escriba %s para confirmar: " ;;
        apagar_recusado)      printf '%s' "La palabra no coincide. No se borró nada." ;;
        instalar_a_escrever)  printf '%s' "Escribiendo el sistema en el disco. NO APAGUE." ;;
        instalar_pronto)      printf '%s' "Instalación completa." ;;
        instalar_falhou)      printf '%s' "Fallo en la instalación: %s" ;;
        simulacao_aviso)      printf '%s' "MODO SIMULACIÓN: no se escribirá nada en el disco." ;;
        # --- dos pantallas a la vez (monitor y puerto serie) ---
        consola_ocupada)       printf '%s' "La instalación ya se está haciendo en otra pantalla (%s)." ;;
        consola_ocupada_dica)  printf '%s' "Use esa pantalla, o espere a que termine." ;;
        consola_monitor)       printf '%s' "monitor y teclado" ;;
        consola_serie)         printf '%s' "puerto serie" ;;
        instalar_ja_concluida) printf '%s' "La instalación ya terminó." ;;
        tecla_enter_voltar)    printf '%s' "Pulse Enter para volver: " ;;
        tecla_enter_recomecar) printf '%s' "Pulse Enter para empezar de nuevo: " ;;
        # --- el final: apagar ANTES de retirar el USB (la raíz vive en él) ---
        instalar_depois_desligar) printf '%s' "Cuando el equipo se apague, retire el USB y enciéndalo de nuevo." ;;
        tecla_enter_desligar)     printf '%s' "Pulse Enter para apagar el equipo: " ;;
        instalar_desligando)      printf '%s' "Apagando... Cuando la pantalla se apague, retire el USB." ;;
        # --- una pantalla asume la instalación detenida en la otra ---
        consola_assumir_dica)     printf '%s' "Si nadie usa esa pantalla, escriba %s para usar esta." ;;
        consola_ocupada_gravando) printf '%s' "Esa pantalla ya está grabando el disco. Espere a que termine." ;;
        consola_assumir_recusado) printf '%s' "No se puede asumir: la otra pantalla ya está grabando el disco." ;;
        consola_assumir_falhou)   printf '%s' "No se pudo asumir la instalación. Intente de nuevo." ;;
        consola_assumida)         printf '%s' "Otra pantalla asumió la instalación. No se borró nada." ;;
        # --- newbond-server-setup (concentrador), no el instalador del CPE ---
        srv_titulo)            printf '%s' "Primera configuración del concentrador NewBond" ;;
        srv_precisa_root)     printf '%s' "Este asistente debe ejecutarse como root." ;;
        srv_ja_configurado)   printf '%s' "Ya existe config en %s; será reemplazada (hay copia)." ;;
        srv_listen_pergunta)  printf '%s' "Dirección de escucha (ej.: :5001): " ;;
        srv_mtls_titulo)      printf '%s' "Configuración de mTLS" ;;
        srv_mtls_opcao_auto)     printf '%s' "1) Automático (recomendado): el concentrador crea su propia autoridad de certificados, y las CPE se autorizan desde la pantalla de gestión" ;;
        srv_mtls_opcao_arquivos) printf '%s' "2) mTLS con mis propios archivos (ya tengo certificado, clave y CA)" ;;
        srv_mtls_opcao_bancada)  printf '%s' "3) generar un conjunto de PRUEBA" ;;
        srv_mtls_opcao_semtls)   printf '%s' "4) sin mTLS (no recomendado)" ;;
        srv_mtls_pergunta)    printf '%s' "Elija 1-4: " ;;
        srv_cert_pergunta)    printf '%s' "Ruta del certificado de este servidor: " ;;
        srv_chave_pergunta)   printf '%s' "Ruta de la clave privada: " ;;
        srv_ca_pergunta)      printf '%s' "Ruta de la CA que firma los CPE: " ;;
        srv_ficheiro_falta)   printf '%s' "No existe o no se puede leer: %s" ;;
        srv_bancada_aviso)    printf '%s' "AVISO: material de PRUEBA, no es para producción." ;;
        srv_sem_mtls_aviso)   printf '%s' "AVISO: sin mTLS; la sección 6.1 lo exige." ;;
        srv_cpes_pergunta)    printf '%s' "Ruta de la lista de CPE admitidos (vacío = ninguno): " ;;
        srv_resumo_titulo)    printf '%s' "Resumen de lo que se escribirá" ;;
        srv_confirmar)        printf '%s' "¿Confirmar y escribir? [s/N]: " ;;
        srv_cancelado)        printf '%s' "No se escribió nada." ;;
        srv_escrito)          printf '%s' "Configuración escrita en %s" ;;
        srv_copia)            printf '%s' "La anterior quedó guardada en %s" ;;
        srv_activar_pergunta) printf '%s' "¿Activar e iniciar el servicio ahora? [s/N]: " ;;
        srv_activado)         printf '%s' "Servicio activado." ;;
        srv_nao_activado)     printf '%s' "Servicio NO activado; comando para activarlo después:" ;;
        srv_auto_titulo)               printf '%s' "Modo automático — la CA propia del concentrador" ;;
        srv_auto_papel_opcao_principal) printf '%s' "1) Principal (recomendado): este concentrador tiene la autoridad de certificados y aprueba las CPE" ;;
        srv_auto_papel_opcao_reserva)   printf '%s' "2) Reserva: entra en acción si el concentrador principal queda fuera de servicio; un administrador aprueba este concentrador en el principal" ;;
        srv_auto_papel_pergunta)        printf '%s' "Elija 1-2 [1]: " ;;
        srv_auto_enderecos_pergunta)   printf '%s' "Dirección pública del concentrador (nombre o IP; puede haber varias, separadas por comas): " ;;
        srv_auto_enderecos_vazio)      printf '%s' "Se necesita al menos una dirección pública: es lo que las CPE usarán para llegar al concentrador." ;;
        srv_auto_a_activar_gerencia)   printf '%s' "Activando la gestión y esperando la autoridad de certificados..." ;;
        srv_auto_gerencia_falhou_activar) printf '%s' "No se pudo activar newbond-gerencia." ;;
        srv_auto_ca_nao_apareceu)      printf '%s' "La autoridad de certificados no apareció en %s. newbond-server NO fue activado." ;;
        srv_auto_ca_pronta)            printf '%s' "Autoridad de certificados lista." ;;
        srv_auto_journal_titulo)       printf '%s' "Últimas líneas del servicio newbond-gerencia:" ;;
        srv_auto_server_falhou_activar) printf '%s' "newbond-gerencia está listo, pero no se pudo activar newbond-server." ;;
        srv_auto_resumo_titulo)        printf '%s' "¡Listo! El concentrador está en funcionamiento." ;;
        srv_auto_painel_linha)         printf '%s' "Panel del administrador: %s (en el primer acceso pedirá crear la contraseña del administrador)" ;;
        srv_auto_firewall_titulo)      printf '%s' "Puertos a abrir en el firewall del centro de datos:" ;;
        srv_auto_porta_video)             printf '%s' "%s/tcp — video de las CPE" ;;
        srv_auto_porta_gerencia)          printf '%s' "5003/tcp — gestión de las CPE" ;;
        srv_auto_porta_adesao)            printf '%s' "5005/tcp — adhesión de CPE nuevas" ;;
        srv_auto_porta_tunel)             printf '%s' "51820/udp — acceso remoto (túnel)" ;;
        srv_auto_porta_abrir_painel)      printf '%s' "8444/tcp — abrir el panel de las CPE" ;;
        srv_auto_porta_painel_operadores) printf '%s' "8443/tcp — panel de operadores (recomendado exponer solo en la red de gestión/VPN)" ;;
        srv_auto_porta_redir)             printf '%s' "%s/tcp — puertos abiertos (conexión de las CPE a la redirección)" ;;
        srv_auto_porta_redir_regras)      printf '%s' "y cada puerto que abra en «Puertos abiertos en el concentrador», en el panel (solo los orígenes que usted permita pueden usarlo)" ;;
        srv_auto_redir_falhou_activar)    printf '%s' "El video está al aire, pero no se pudo activar newbond-redir (puertos abiertos). Vea: journalctl -u newbond-redir" ;;
        srv_redir_endereco_privado)       printf '%s' "La dirección %s es de una red interna y nadie de afuera la alcanza: no se usó como dirección pública de los puertos abiertos. La pantalla «Puertos abiertos en el concentrador» pedirá al operador que confirme la dirección con soporte. Para corregirlo, ejecute este asistente de nuevo e incluya el IPv4 público del concentrador en la lista." ;;
        # --- concentrador de reserva (ADR 0138 §3, A3.2) ---
        srv_auto_reserva_titulo)             printf '%s' "Modo automático — concentrador de reserva" ;;
        srv_auto_reserva_principal_pergunta) printf '%s' "Dirección (nombre o IP) del concentrador principal: " ;;
        srv_auto_reserva_principal_vazio)    printf '%s' "Se necesita la dirección del concentrador principal." ;;
        srv_auto_reserva_enderecos_pergunta) printf '%s' "Dirección pública de este concentrador de reserva (nombre o IP; puede haber varias, separadas por comas): " ;;
        srv_auto_reserva_codigo_titulo)      printf '%s' "Código de emparejamiento" ;;
        srv_auto_reserva_instrucao)          printf '%s' "En el panel del concentrador principal, apruebe la solicitud de este concentrador de reserva verificando el código %s" ;;
        srv_auto_reserva_codigo_nao_apareceu) printf '%s' "No se pudo obtener el código de emparejamiento del concentrador principal. Revise la dirección y el código de invitación: la invitación vale 24 horas y una sola vez. Si hace falta, genere otra en el panel del principal y ejecute este asistente de nuevo." ;;
        # --- invitación de emparejamiento (contrato de 2026-10-01, parte D) ---
        srv_auto_reserva_convite_pergunta)   printf '%s' "Código de invitación generado en el panel del concentrador principal (ej.: ABCD-EFGH-JKMN): " ;;
        srv_auto_reserva_convite_invalido)   printf '%s' "Ese código no tiene el formato correcto: son 12 letras y números, como ABCD-EFGH-JKMN (no existen las letras I, L, O y U). Revíselo y escríbalo de nuevo." ;;
        srv_auto_reserva_convite_desistiu)   printf '%s' "Sin un código de invitación válido no se puede emparejar. Genere una invitación en el panel del concentrador principal y ejecute este asistente de nuevo." ;;
        srv_auto_reserva_convite_ja_pareada) printf '%s' "Este concentrador de reserva ya está emparejado: deje el código de invitación en blanco para mantenerlo como está." ;;
        srv_auto_reserva_convite_revogada)   printf '%s' "Este concentrador fue retirado por el concentrador principal. Para volver a usarlo como reserva, genere una invitación en el principal e infórmela aquí." ;;
        srv_auto_reserva_convite_guardado_pareada) printf '%s' "Este concentrador ya está emparejado: el código se guardó y solo se usará si el concentrador principal lo retira." ;;
        srv_auto_reserva_convite_recusado)   printf '%s' "El concentrador principal rechazó el código de invitación: no existe, ya se usó o venció (vale 24 horas). Genere otra en el panel del principal y ejecute este asistente de nuevo." ;;
        srv_auto_reserva_convite_resumo)     printf '%s' "Código de invitación: se guardará en %s (no se muestra aquí)" ;;
        srv_auto_reserva_convite_gravado)    printf '%s' "Código de invitación guardado en %s." ;;
        srv_auto_reserva_convite_nao_gravou) printf '%s' "No se pudo guardar el código de invitación en %s. No se activó nada." ;;
        srv_auto_reserva_nao_aprovado)       printf '%s' "Nadie aprobó este concentrador de reserva a tiempo. newbond-server NO fue activado." ;;
        srv_auto_reserva_tente_de_novo)      printf '%s' "La gestión sigue activa, esperando aprobación. En cuanto alguien lo apruebe en el principal, ejecute este asistente de nuevo para terminar." ;;
        srv_auto_reserva_resumo_titulo)      printf '%s' "¡Listo! Este concentrador de reserva está emparejado." ;;
        # --- historial de uso (ADR 0140, fase H4) ---
        srv_historico_desligado) printf '%s' "Historial de uso desactivado: la base de datos (TimescaleDB) no está instalada. El concentrador funciona sin ella; para activarla, instale el paquete y vuelva a ejecutar este asistente." ;;
        srv_historico_ligado)    printf '%s' "Historial de uso activado (TimescaleDB)." ;;
        srv_historico_simulado)  printf '%s' "Historial de uso: bajo --raiz, nada se ejecuta en PostgreSQL (reiniciaría el servicio y crearía el rol/base newbond)." ;;
        srv_historico_falhou)    printf '%s' "No se pudo configurar el historial de uso (%s). Queda desactivado; revise: journalctl -u postgresql" ;;
        # --- historial activado tras una actualización (newbond-server-setup --so-historico) ---
        srv_historico_so_a_ligar) printf '%s' "Historial de uso: la base de datos (TimescaleDB) llegó después de configurar este concentrador. Activando el historial ahora." ;;
        srv_historico_so_pg_nao_pronto) printf '%s' "PostgreSQL no estuvo listo a tiempo. El historial de uso sigue desactivado; lo intento de nuevo en el próximo arranque." ;;
        srv_historico_so_opcao_falhou) printf '%s' "La base de datos quedó configurada, pero no pude escribir la opción del historial en %s. El historial sigue desactivado; lo intento de nuevo en el próximo arranque." ;;
        srv_historico_so_gerencia_nao_reiniciou) printf '%s' "Historial activado en la configuración, pero no pude reiniciar el servicio %s. Se aplicará cuando el servicio se reinicie." ;;
        # --- reiniciar para que valga la config nueva ---
        srv_vai_reiniciar)       printf '%s' "El servicio %s ya está en marcha. Se reiniciará para usar la configuración nueva, y el video de las CPE se detiene unos segundos." ;;
        srv_servico_reiniciado)  printf '%s' "Servicio %s reiniciado: la configuración nueva ya está vigente." ;;
        srv_config_so_depois_de_reiniciar) printf '%s' "La configuración nueva solo vale después de reiniciar el servicio: systemctl restart %s" ;;
        # --- excepción de destino (-destino-permitir) ya configurada ---
        srv_destino_permitir_mantido)  printf '%s' "Se mantuvo la excepción de destino que ya estaba configurada: %s" ;;
        srv_destino_permitir_removido) printf '%s' "La excepción de destino que estaba configurada (%s) fue retirada: solo funciona con mTLS." ;;
        srv_destino_permitir_ilegivel) printf '%s' "No se pudo mantener la excepción de destino que estaba configurada (%s). Queda solo en la copia del archivo anterior; revísela y agréguela de nuevo." ;;
        # --- la descarga mensual de las bases de DB-IP (avisa_geoip, hallazgo K29) ---
        srv_geoip_aviso)        printf '%s' "Los informes mostrarán nombre y lugar de cada destino en internet." ;;
        srv_geoip_baixa)        printf '%s' "Para eso, este servidor descarga cada mes una base gratuita desde:" ;;
        srv_geoip_desligar)     printf '%s' "Para no descargar más, agregue esta opción a las del archivo de abajo:" ;;
        srv_geoip_bases_ficam)  printf '%s' "Los informes siguen usando las bases que ya están en este servidor." ;;
        srv_geoip_sem_bases)    printf '%s' "Este servidor todavía no tiene las bases: llegan con la descarga." ;;
        srv_geoip_sem_bases_desligar) printf '%s' "Si la desactiva antes, los informes quedan sin nombre ni lugar." ;;
        srv_geoip_mantida_sem_bases) printf '%s' "Este servidor no tiene las bases, y sin la descarga no llegan:" ;;
        srv_geoip_sem_nome_lugar) printf '%s' "los informes quedan sin nombre ni lugar de los destinos." ;;
        srv_geoip_religar)      printf '%s' "Para tenerlas, quite la opción de arriba y reinicie el servicio." ;;
        srv_geoip_mantida)      printf '%s' "La descarga mensual sigue desactivada, como ya estaba:" ;;
        srv_geoip_reiniciar)    printf '%s' "y reinicie el servicio: systemctl restart newbond-gerencia" ;;
        # --- verificar hardware (instalador del CPE, verificar-hardware.sh) ---
        disco_opcao_verificar)  printf '%s' "  0) Verificar el hardware de esta máquina (no escribe nada)" ;;
        hw_titulo)              printf '%s' "Verificación de hardware" ;;
        hw_nada_gravado)        printf '%s' "No se escribe nada en el disco interno." ;;
        hw_tag_ok)              printf '%s' "OK" ;;
        hw_tag_aviso)           printf '%s' "AVISO" ;;
        hw_tag_falta)           printf '%s' "FALTA" ;;
        hw_tag_info)            printf '%s' "INFO" ;;
        hw_dado)                printf '%s' "dato: %s" ;;
        hw_maquina)             printf '%s' "Máquina: %s" ;;
        hw_cpu)                 printf '%s' "Procesador: %s" ;;
        hw_cpu_nucleos)         printf '%s' "Núcleos del procesador: %s" ;;
        hw_cpu_threads)         printf '%s' "(%s hilos)" ;;
        hw_cpu_64_falta)        printf '%s' "El procesador no es de 64 bits: NewBond no funciona en él." ;;
        hw_cpu_aes_ok)          printf '%s' "El procesador tiene AES-NI (cifrado rápido)." ;;
        hw_cpu_aes_falta)       printf '%s' "El procesador no tiene AES-NI: el cifrado será lento." ;;
        hw_cpu_avx2_sim)        printf '%s' "El procesador tiene AVX2." ;;
        hw_cpu_avx2_nao)        printf '%s' "El procesador no tiene AVX2 (no impide la instalación)." ;;
        hw_ram)                 printf '%s' "Memoria RAM: %s" ;;
        hw_ram_pouca)           printf '%s' "Menos de 4 GB de RAM: por debajo de lo recomendado." ;;
        hw_disco)               printf '%s' "Disco interno: %s" ;;
        hw_disco_usb)           printf '%s' "Disco USB (no es interno): %s" ;;
        hw_disco_pendrive)      printf '%s' "USB de este instalador: %s" ;;
        hw_disco_nenhum)        printf '%s' "Ningún disco interno: no hay dónde instalar." ;;
        hw_disco_pequeno)       printf '%s' "Ningún disco interno de 4 GB o más: el sistema no cabe." ;;
        hw_disco_abaixo)        printf '%s' "El mayor disco interno tiene menos de 32 GB (recomendado)." ;;
        hw_controladora_sem_driver) printf '%s' "Controladora de disco sin driver: %s" ;;
        hw_rede_cabo_sim)       printf '%s' "Puerto de red %s: cable conectado" ;;
        hw_rede_cabo_nao)       printf '%s' "Puerto de red %s: sin cable" ;;
        hw_rede_cabo_desconhecido) printf '%s' "Puerto de red %s: apagado (cable no verificado)" ;;
        hw_rede_sem_driver)     printf '%s' "Tarjeta de red sin driver (no reconocida): %s" ;;
        hw_rede_sem_porta)      printf '%s' "Tarjeta de red con driver %s, pero el puerto no apareció." ;;
        hw_wifi_sem_driver)     printf '%s' "Tarjeta Wi-Fi sin driver (NewBond no la usa): %s" ;;
        hw_rede_total)          printf '%s' "Puertos de red funcionando: %s" ;;
        hw_rede_nenhuma)        printf '%s' "Ningún puerto de red funcionando." ;;
        hw_rede_uma)            printf '%s' "Solo 1 puerto de red: la CPE necesita 2 (WAN y LAN)." ;;
        hw_firmware_falta)      printf '%s' "Falta el firmware %s" ;;
        hw_firmware_falta_ok)   printf '%s' "Falta el firmware %s, pero la tarjeta funcionó." ;;
        hw_firmware_falta_outro) printf '%s' "Falta el firmware %s (no es tarjeta de red: no impide)." ;;
        hw_firmware_pacote)     printf '%s' "Viene en el paquete %s: pida al soporte." ;;
        hw_firmware_nenhum)     printf '%s' "Ningún firmware faltante." ;;
        hw_usb)                 printf '%s' "Dispositivo USB: %s" ;;
        hw_modem_ok)            printf '%s' "Módem USB listo: %s" ;;
        hw_modem_sem_interface) printf '%s' "Módem USB sin interfaz de datos (falta driver): %s" ;;
        hw_modem_modo_disco)    printf '%s' "Módem USB en modo pendrive (necesita modeswitch): %s" ;;
        hw_modem_nenhum)        printf '%s' "Ningún módem USB encontrado." ;;
        hw_serie)               printf '%s' "Puerto serie: %s" ;;
        hw_serie_nenhuma)       printf '%s' "Ningún puerto serie encontrado." ;;
        hw_arranque_uefi)       printf '%s' "Arranque en modo UEFI." ;;
        hw_arranque_bios)       printf '%s' "Arranque en modo BIOS (legacy)." ;;
        hw_montagem_alheia)     printf '%s' "%s vino del disco interno (NewBond antiguo), no del USB." ;;
        hw_resultado_titulo)    printf '%s' "RESULTADO" ;;
        hw_pronto)              printf '%s' "Listo para instalar." ;;
        hw_pronto_avisos)       printf '%s' "Listo para instalar, pero lea los ítems AVISO." ;;
        hw_nao_pronto)          printf '%s' "Aún no se puede instalar: vea los ítems FALTA." ;;
        hw_dica_suporte)        printf '%s' "Envíe el informe (o una foto de la pantalla) al soporte." ;;
        hw_salvo)               printf '%s' "Informe guardado en el USB, en la unidad NEWBOND:" ;;
        hw_salvo_esp)           printf '%s' "Informe guardado en la partición EFI del USB (Windows no la muestra):" ;;
        hw_salvo_em)            printf '%s' "Informe guardado en:" ;;
        hw_salvo_temporario)    printf '%s' "No se pudo guardar en el USB. Copia temporal (se pierde al apagar):" ;;
        hw_enter_voltar)        printf '%s' "Pulse Enter para volver a la lista de discos: " ;;
        hw_enter_continuar)     printf '%s' "Pulse Enter para continuar: " ;;
        instalar_alvo_em_uso)   printf '%s' "El disco %s está en uso por este sistema (montado)." ;;
        instalar_sem_payload)   printf '%s' "El USB está incompleto: falta el sistema a grabar." ;;
        instalar_nada_apagado)  printf '%s' "No se borró nada. Use la opción 0 y envíe el informe al soporte." ;;
        hw_ausente)             printf '%s' "La verificación de hardware no está en este USB." ;;
        hw_por_falta)           printf '%s' "Voy a verificar el hardware para mostrar la causa." ;;
        # --- el producto (cpe | concentrador): texto y umbrales del instalador ---
        produto_nome_cpe)            printf '%s' "NewBond CPE" ;;
        produto_nome_concentrador)   printf '%s' "NewBond Concentrador" ;;
        instalar_proximo_concentrador) printf '%s' "Al primer arranque, pedirá la red y la contraseña." ;;
        hw_disco_pequeno_conc)  printf '%s' "Ningún disco interno de 32 GB o más: no cabe el concentrador." ;;
        # --- 1.er arranque del concentrador (newbond-primeiro-arranque) ---
        pa_titulo)              printf '%s' "NewBond Concentrador - primera configuración" ;;
        pa_passos)              printf '%s' "Pasos: 1) red   2) acceso   3) configuración de NewBond" ;;
        pa_passo_rede)          printf '%s' "Paso 1 de 3: red" ;;
        pa_passo_acesso)        printf '%s' "Paso 2 de 3: acceso" ;;
        pa_passo_setup)         printf '%s' "Paso 3 de 3: configuración de NewBond" ;;
        pa_ocupada)             printf '%s' "La configuración ya se está haciendo en otra pantalla (%s)." ;;
        pa_ja_concluida)        printf '%s' "La configuración ya terminó." ;;
        pa_rede_ja_feita)       printf '%s' "La red ya está configurada. Pasando al siguiente paso." ;;
        pa_acesso_ja_feito)     printf '%s' "El acceso ya está configurado. Pasando al siguiente paso." ;;
        pa_rede_falhou)         printf '%s' "La red no se configuró." ;;
        pa_setup_nao_concluiu)  printf '%s' "La configuración de NewBond no se completó." ;;
        pa_rede_agora)          printf '%s' "Red ahora:" ;;
        pa_rede_endereco)       printf '%s' "Dirección: %s" ;;
        pa_rede_sem_endereco)   printf '%s' "Ninguna tarjeta tiene dirección ahora." ;;
        pa_rede_sem_gateway)    printf '%s' "No hay router (gateway) configurado." ;;
        pa_rede_gw_ok)          printf '%s' "El router %s responde." ;;
        pa_rede_gw_falha)       printf '%s' "El router %s NO responde." ;;
        pa_setup_dica_rede)     printf '%s' "Si la red está mal, escriba R para rehacerla." ;;
        pa_setup_repetir_pergunta) printf '%s' "Enter repite la configuración; R rehace la red: " ;;
        pa_unbound_falhou)      printf '%s' "No se pudo iniciar unbound. Vea: journalctl -u unbound" ;;
        pa_pronto_titulo)       printf '%s' "Configuración completa." ;;
        pa_pronto_login)        printf '%s' "En la pantalla de login, entre como root con la contraseña creada." ;;
        pa_pronto_rede)         printf '%s' "Para cambiar la red después, ejecute newbond-rede, o use el panel." ;;
        pa_instrumento_falta)   printf '%s' "Falta el programa %s en esta máquina. Llame al soporte." ;;
        # --- red inicial (rede-inicial.sh) ---
        rede_titulo)            printf '%s' "Red del concentrador" ;;
        rede_intro)             printf '%s' "Elija la tarjeta de red y cómo recibe su dirección." ;;
        rede_placas_cabecalho)  printf '%s' "  #  TARJETA      MAC               ESTADO" ;;
        rede_nenhuma_placa)     printf '%s' "No se encontró ninguna tarjeta de red." ;;
        rede_placa_pergunta)    printf '%s' "Número de tarjeta: " ;;
        rede_estado_cabo)       printf '%s' "cable conectado" ;;
        rede_estado_sem_cabo)   printf '%s' "sin cable" ;;
        rede_estado_desconhecido) printf '%s' "cable no verificado" ;;
        rede_verificando_cabos) printf '%s' "Verificando los cables de red (unos segundos)..." ;;
        rede_v4_opcoes)         printf '%s' "IPv4:  1) automático (DHCP)   2) dirección fija" ;;
        rede_v4_pergunta)       printf '%s' "Elija 1 o 2 [1]: " ;;
        rede_v4_endereco_pergunta) printf '%s' "Dirección y máscara (ej.: 192.168.0.10/24): " ;;
        rede_v4_gateway_pergunta) printf '%s' "Gateway/router (ej.: 192.168.0.1; Enter si no hay): " ;;
        rede_v6_opcoes)         printf '%s' "IPv6:  1) apagado   2) automático (SLAAC)   3) dirección fija" ;;
        rede_v6_pergunta)       printf '%s' "Elija 1 a 3 [1]: " ;;
        rede_v6_endereco_pergunta) printf '%s' "Dirección y prefijo (ej.: 2001:db8::10/64): " ;;
        rede_v6_gateway_pergunta) printf '%s' "Gateway IPv6 (Enter si no hay): " ;;
        # El DNS es OPCIONAL: solo reenvía para el unbound propio del concentrador,
        # que sin él resuelve solo, desde los servidores raíz.
        rede_dns_intro1)        printf '%s' "DNS opcional: indique 1 o 2 servidores, separados por espacio." ;;
        rede_dns_intro2)        printf '%s' "Enter: el concentrador resuelve los nombres solo (servidores raíz)." ;;
        rede_dns_pergunta)      printf '%s' "Servidor DNS (Enter para omitir): " ;;
        rede_dns_pergunta_obrig) printf '%s' "Servidor DNS (1 o 2, separados por espacio): " ;;
        rede_dns_nenhum)        printf '%s' "ninguno (el concentrador resuelve solo)" ;;
        rede_dns_pede)          printf '%s' "El DNS local no inició. Indique un DNS para no quedar sin ninguno." ;;
        rede_dns_reserva)       printf '%s' "Sin el DNS local, la máquina usa el DNS que usted indicó." ;;
        rede_dns_vazio)         printf '%s' "Indique al menos un servidor DNS." ;;
        rede_dns_muitos)        printf '%s' "Indique como máximo 2 servidores DNS." ;;
        rede_dns_invalido)      printf '%s' "El DNS %s no es una dirección válida." ;;
        rede_dns_nao_serve)     printf '%s' "Ese DNS no sirve. Revise los números y escríbalo de nuevo." ;;
        rede_testando_dns)      printf '%s' "Probando la resolución de nombres..." ;;
        rede_dns_resolve_ok)    printf '%s' "Los nombres de internet se están resolviendo." ;;
        rede_dns_nao_resolve1)  printf '%s' "El concentrador no puede resolver nombres por internet." ;;
        rede_dns_nao_resolve2)  printf '%s' "Si el datacenter bloquea el DNS, indique el DNS del datacenter." ;;
        rede_dns_nao_resolve_pergunta) printf '%s' "Enter prueba otra vez; D indica un DNS; C sigue así: " ;;
        rede_nome_pergunta)     printf '%s' "Nombre de esta máquina [%s]: " ;;
        rede_nome_invalido)     printf '%s' "Nombre inválido: solo letras, números y guion (hasta 63)." ;;
        rede_texto_invalido)    printf '%s' "Texto inválido: solo números, letras A-F, '.', ':' y '/'." ;;
        rede_resumo_titulo)     printf '%s' "Revise antes de guardar" ;;
        rede_resumo_placa)      printf '%s' "Tarjeta: %s" ;;
        rede_resumo_v4)         printf '%s' "IPv4:    %s" ;;
        rede_resumo_v6)         printf '%s' "IPv6:    %s" ;;
        rede_resumo_dns)        printf '%s' "DNS:     %s" ;;
        rede_resumo_nome)       printf '%s' "Nombre:  %s" ;;
        rede_modo_dhcp)         printf '%s' "automático (DHCP)" ;;
        rede_modo_slaac)        printf '%s' "automático (SLAAC)" ;;
        rede_modo_nenhum)       printf '%s' "apagado" ;;
        rede_aviso_definitivo)  printf '%s' "Una vez guardada, la red cambia en el panel o con newbond-rede." ;;
        rede_confirmar_pergunta) printf '%s' "¿Guardar esta configuración? [s/N]: " ;;
        rede_cancelado)         printf '%s' "No se guardó nada. Empecemos de nuevo." ;;
        rede_gravando)          printf '%s' "Guardando la red..." ;;
        rede_gravada)           printf '%s' "Red guardada." ;;
        rede_recusada)          printf '%s' "No se guardó la red. Corrija lo que aparece abajo:" ;;
        rede_erro_helper)       printf '%s' "No se pudo guardar la red: %s" ;;
        rede_ja_configurada)    printf '%s' "Esta máquina ya tiene la red configurada. Nada que rehacer." ;;
        rede_ligando)           printf '%s' "Iniciando el servicio de red..." ;;
        rede_liga_falhou)       printf '%s' "No se pudo iniciar el servicio de red (systemd-networkd)." ;;
        rede_testando)          printf '%s' "Probando la red (puede tardar unos segundos)..." ;;
        rede_ok)                printf '%s' "Red funcionando: el router respondió." ;;
        rede_sem_cabo)          printf '%s' "La tarjeta %s no tiene cable. Conecte el cable de red." ;;
        rede_sem_ip)            printf '%s' "La tarjeta no recibió dirección. Revise el cable y el DHCP." ;;
        rede_gateway_falhou)    printf '%s' "El router %s no respondió." ;;
        rede_sem_gateway)       printf '%s' "No hay router que probar. La red no se probó." ;;
        rede_teste_dica1)       printf '%s' "La red ya se guardó, pero la prueba falló." ;;
        rede_teste_dica2)       printf '%s' "Si la dirección está mal, escriba R para rehacer la red." ;;
        rede_teste_pergunta)    printf '%s' "Enter prueba de nuevo; R rehace la red; C sigue igual: " ;;
        # --- rehacer la red ya guardada (rede-inicial.sh --refazer, newbond-rede) ---
        rede_titulo_refazer)    printf '%s' "Rehacer la red del concentrador" ;;
        rede_aviso_refazer)     printf '%s' "Esto cambia la red ahora. La conexión remota (SSH) puede caerse." ;;
        rede_refazer_virgem)    printf '%s' "La red aún no está configurada: termine la primera configuración." ;;
        rede_sem_mudanca)       printf '%s' "La configuración nueva es igual a la actual. Nada cambió." ;;
        rede_placa_fica)        printf '%s' "La tarjeta %s sigue configurada como estaba." ;;
        rede_refazer_fica1)     printf '%s' "Solo cambian el IPv4 y el IPv6 de la tarjeta elegida." ;;
        rede_refazer_fica2)     printf '%s' "Las VLAN, rutas y otras tarjetas quedan como están." ;;
        nr_remoto)              printf '%s' "Por acceso remoto, cambie la red en el panel, que tiene modo seguro." ;;
        nr_precisa_root)        printf '%s' "Este comando debe ejecutarse como root, en la consola local." ;;
        nr_atual)               printf '%s' "Red actual de esta máquina:" ;;
        nr_aviso)               printf '%s' "La conexión remota (SSH) puede caerse al cambiar la red." ;;
        nr_confirmar)           printf '%s' "¿Continuar? [s/N]: " ;;
        nr_cancelado)           printf '%s' "No se cambió nada." ;;
        # --- acceso (contraseña local y clave SSH) ---
        acesso_senha_intro1)    printf '%s' "Cree la contraseña para entrar a esta máquina por esta pantalla." ;;
        acesso_senha_intro2)    printf '%s' "El usuario es root. Use letras sin acento, números y símbolos." ;;
        acesso_senha_pergunta)  printf '%s' "Nueva contraseña: " ;;
        acesso_senha_repita)    printf '%s' "Repita la contraseña: " ;;
        acesso_senha_curta)     printf '%s' "La contraseña necesita al menos %s caracteres." ;;
        acesso_senha_ascii)     printf '%s' "Use solo letras sin acento, números y símbolos comunes." ;;
        acesso_senha_diferente) printf '%s' "Las contraseñas no coinciden. Intente de nuevo." ;;
        acesso_senha_falhou)    printf '%s' "No se pudo guardar la contraseña. Intente de nuevo." ;;
        acesso_senha_ok)        printf '%s' "Contraseña guardada." ;;
        acesso_chave_intro1)    printf '%s' "Para entrar también por SSH, pegue aquí su clave pública." ;;
        acesso_chave_intro2)    printf '%s' "Es una sola línea, que empieza con ssh-ed25519 o ssh-rsa." ;;
        acesso_chave_intro3)    printf '%s' "Para omitir, pulse Enter: nadie entrará por SSH." ;;
        acesso_chave_pergunta)  printf '%s' "Clave pública (Enter para omitir): " ;;
        acesso_chave_invalida)  printf '%s' "Eso no parece una clave pública. Intente de nuevo." ;;
        acesso_chave_ok)        printf '%s' "Clave aceptada (%s)." ;;
        acesso_chave_falhou)    printf '%s' "No se pudo guardar la clave." ;;
        acesso_sem_chave1)      printf '%s' "Sin clave, el SSH no tiene cómo entrar." ;;
        acesso_sem_chave2)      printf '%s' "La entrada será solo por esta pantalla, con la contraseña." ;;
        *)                    printf '%s' "" ;;
    esac
}
