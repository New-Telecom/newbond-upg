# shellcheck shell=sh
#
# SEM SHEBANG -- mesma razão do idiomas.sh: isto é biblioteca sourced, nunca
# executada directamente, e marcá-la como 100755 só arrastava um bit que
# não serve para nada (ver o cabeçalho de `poc/lab/common.sh` e a trava de
# higiene descrita no §8 do CLAUDE.md).
#
# tela.sh -- apresentação orientada a LINHA para o instalador do CPE.
#
# O instalador corre na consola série de um appliance, num VT100 de 80x24
# (ver o pedido que gerou este ficheiro). Isso risca da lista quase tudo o
# que um instalador normalmente usaria: `dialog`/`whiptail` desenham caixas
# com endereçamento de cursor que um VT100 real não garante entender por
# igual em toda a série de appliances, e cor nenhuma é garantida num link
# série. O que sobra, e o que este ficheiro dá, é: imprime, pergunta, lê
# uma linha.
#
# E desde 2026-10-02 corre TAMBÉM no monitor e teclado (tty1), ao mesmo tempo
# que na série: há appliances sem porta de consola. O desenho orientado a
# linha serve igual às duas telas; a única diferença é a fonte -- ver
# `_tela_txt`, logo abaixo.
#
# CANAIS -- STDOUT vs STDERR, E É A PARTE QUE JÁ ENGANOU UMA VEZ:
#   Numa consola série a pergunta e a resposta aparecem no mesmo ecrã, o
#   que convida a supor que também partilham o mesmo CANAL. Não partilham.
#   `tela_pergunta` é chamada como `X=$(tela_pergunta "...")`, e tudo o que
#   essa função escrever em stdout entra dentro de X -- incluindo o texto
#   da própria pergunta, se for lá que ele for parar. Isso já aconteceu
#   nesta função: a pergunta em stdout colava-se à resposta, e o portão de
#   confirmação do APAGAR nunca coincidia com a palavra esperada, porque X
#   vinha com o prompt à frente. Por isso:
#     - tela_pergunta escreve a PERGUNTA em stderr (visível na consola,
#       INVISÍVEL para `$(...)`) e só a RESPOSTA em stdout.
#     - tela_aviso e tela_erro vão para stderr, pela mesma razão de fundo:
#       são texto de estado, não dado -- nenhum dos dois pode ser o que um
#       `$(...)` a jusante captura por engano.
#     - tela_linha, tela_titulo, tela_regua e tela_coluna são CONTEÚDO (o
#       texto da tela, a tabela de discos) e ficam em stdout, onde um
#       `$(...)` os pode legitimamente capturar.
#
# 72 colunas e não 80 nas linhas de largura fixa (régua e tabela de discos):
# sobram 8 de margem, e um terminal que faz "wrap" a 80 não parte a linha a
# meio -- que na tabela de discos seria a diferença entre ler "500G" e ler
# "50" seguido de "0G" numa linha à parte.

# ---------------------------------------------------------------------------
# 🔴 NO MONITOR, O KERNEL NÃO TEM LETRA PARA «Ã»
# ---------------------------------------------------------------------------
# O pendrive não leva `console-setup` nem `kbd` (nem `setfont`): a tela do
# monitor (tty1) desenha com a fonte EMBUTIDA no kernel, que é a do IBM PC
# (CP437). Ela tem «é», «ç», «á» -- e NÃO tem «ã», «õ», nem quase nenhuma
# maiúscula acentuada. O que se leria no monitor, na linha mais importante do
# instalador, era «N?O DESLIGUE» (ou um losango no lugar do «Ã»).
#
# Por isso, quando a tela é o monitor (`NB_TELA_ASCII=1`, decidido pelo
# `instalar.sh` a partir do nome da consola), o texto sai SEM ACENTO: «NAO
# DESLIGUE» lê-se; «N?O» obriga a adivinhar. Na porta serial o texto segue
# como está: lá quem desenha é o programa do técnico (PuTTY e afins), que
# hoje fala UTF-8.
#
# A troca é por BYTES (`LC_ALL=C`), letra a letra, e não por `iconv
# //TRANSLIT`: o `iconv` só translitera com um locale UTF-8 instalado, e no
# locale C devolve «?» -- exactamente o que se queria evitar. O `tr` do fim é
# a rede: um acento que esta lista não conheça sai como «?», e nunca como um
# byte que a fonte desenhe como lixo.
_tela_txt() {
    if [ "${NB_TELA_ASCII:-0}" != "1" ]; then
        printf '%s' "$1"
        return 0
    fi
    printf '%s' "$1" | LC_ALL=C sed \
        -e 's/á/a/g;s/à/a/g;s/â/a/g;s/ã/a/g;s/ä/a/g' \
        -e 's/Á/A/g;s/À/A/g;s/Â/A/g;s/Ã/A/g;s/Ä/A/g' \
        -e 's/é/e/g;s/è/e/g;s/ê/e/g;s/ë/e/g' \
        -e 's/É/E/g;s/È/E/g;s/Ê/E/g;s/Ë/E/g' \
        -e 's/í/i/g;s/ì/i/g;s/î/i/g;s/ï/i/g' \
        -e 's/Í/I/g;s/Ì/I/g;s/Î/I/g;s/Ï/I/g' \
        -e 's/ó/o/g;s/ò/o/g;s/ô/o/g;s/õ/o/g;s/ö/o/g' \
        -e 's/Ó/O/g;s/Ò/O/g;s/Ô/O/g;s/Õ/O/g;s/Ö/O/g' \
        -e 's/ú/u/g;s/ù/u/g;s/û/u/g;s/ü/u/g' \
        -e 's/Ú/U/g;s/Ù/U/g;s/Û/U/g;s/Ü/U/g' \
        -e 's/ç/c/g;s/Ç/C/g;s/ñ/n/g;s/Ñ/N/g' \
        -e 's/¿/?/g;s/¡/!/g;s/«/"/g;s/»/"/g;s/º/o/g;s/ª/a/g' \
        -e 's/—/-/g;s/–/-/g' \
        | LC_ALL=C tr '\200-\377' '?'
}

tela_limpa() {
    # ESC [ H ESC [ 2J -- a ÚNICA escape sequence deste ficheiro inteiro, e
    # é deliberado: uma imagem mínima não tem `tput`/ncurses instalados por
    # omissão, e negociar capacidades de terminal é exactamente o tipo de
    # coisa que este instalador está desenhado para NÃO precisar. Um VT100
    # real interpreta a sequência; um terminal que não a entenda ignora os
    # bytes e simplesmente não limpa o ecrã -- falha cosmética, nunca
    # funcional, que é a troca certa numa tela de instalação.
    printf '\033[H\033[2J'
}

tela_titulo() {
    titulo=$(_tela_txt "$1")
    printf '%s\n' "$titulo"
    # A linha de '=' tem o comprimento do título, gerada a contar caracteres
    # em vez de recortada de um literal fixo: um literal destes erra-se por
    # um traço a mais ou a menos ao editar, e o erro só se vê a olhar para o
    # ecrã a direito -- um `while` que conta é chato de ler mas não erra.
    n=${#titulo}
    i=0
    linha=""
    while [ "$i" -lt "$n" ]; do
        linha="${linha}="
        i=$((i + 1))
    done
    printf '%s\n' "$linha"
}

tela_linha() {
    printf '%s\n' "$(_tela_txt "$1")"
}

# stderr: ver a nota de canais no cabeçalho.
tela_aviso() {
    printf '!! %s\n' "$(_tela_txt "$1")" >&2
}

# stderr: ver a nota de canais no cabeçalho.
tela_erro() {
    printf '** %s\n' "$(_tela_txt "$1")" >&2
}

tela_regua() {
    i=0
    linha=""
    while [ "$i" -lt 72 ]; do
        linha="${linha}-"
        i=$((i + 1))
    done
    printf '%s\n' "$linha"
}

tela_coluna() {
    # $1=numero $2=dispositivo $3=tamanho $4=modelo
    n="$1"
    dev="$2"
    tam="$3"
    modelo=$(_tela_txt "$4")
    # A especificação só exige truncar o MODELO -- é o único campo de
    # comprimento não controlado por nós (vem do firmware do disco, e um
    # firmware defeituoso ou hostil pode devolver o que quiser). Truncam-se
    # também dispositivo e tamanho, por defesa: esta é a tabela mais
    # perigosa do instalador -- é dela que sai o número que o operador vai
    # escrever para apagar um disco -- e desalinhá-la não é um defeito
    # cosmético aqui, é um risco de apagar o disco errado.
    dev=$(printf '%s' "$dev" | cut -c1-14)
    tam=$(printf '%s' "$tam" | cut -c1-9)
    # Orçamento: "%3s) " (5) + dev (14) + " " (1) + tam (9) + " " (1) = 30.
    # 72 - 30 = 42 para o modelo, e a linha inteira nunca passa de 72.
    modelo=$(printf '%s' "$modelo" | cut -c1-42)
    printf '%3s) %-14s %-9s %s\n' "$n" "$dev" "$tam" "$modelo"
}

# ---------------------------------------------------------------------------
# 🔴 QUEM É DONO DE UMA CONSOLA SÉRIE FIXA A DISCIPLINA DE LINHA
# ---------------------------------------------------------------------------
# MEDIDO a 2026-09-21, a conduzir o instalador pela série de uma VM: o `read`
# recebeu `1\r` — o CR do Enter **não estava a ser convertido**. Com a lista
# certa à frente dos olhos, o instalador respondia «Number not in the list».
#
# ⚠️ E supor o contrário é pior do que parece, nos dois sentidos:
#
#   • sem `icrnl`, um terminal que mande **só CR** (PuTTY, minicom, screen — a
#     norma) nunca termina uma linha, e o instalador fica **pendurado no
#     primeiro prompt**, sem dar erro nenhum;
#   • sem `-inlcr`, um terminal que mande só LF via as linhas trocadas.
#
# Uma bancada com teclado e ecrã nunca mostra nada disto. A consola é o único
# sítio onde este programa vai correr, e por isso a disciplina **declara-se**.
# ⚠️ No monitor (tty1) vale o mesmo: o teclado de um terminal virtual do Linux
# também manda o Enter como CR, e quem o converte é o mesmo `icrnl` — que o
# `TTYReset=yes` da unidade repõe, e que esta função declara de novo.
# Se não houver `stty`, ou se o descritor não for um terminal, segue-se em
# frente: o `tela_pergunta` ainda tira o CR sozinho.
tela_prepara_terminal() {
    command -v stty >/dev/null 2>&1 || return 0
    stty icrnl -inlcr echo icanon 2>/dev/null || true
}

tela_pergunta() {
    # A pergunta vai para stderr -- ver a nota de canais no cabeçalho deste
    # ficheiro. Só a resposta, sem newline a mais, vai para stdout: é o que
    # permite `X=$(tela_pergunta "Escolha 1-3: ")` capturar exactamente o
    # que o utilizador escreveu, nem mais nem menos.
    printf '%s' "$(_tela_txt "$1")" >&2
    # ⚠️ O FIM DA ENTRADA DEVOLVE 1, EXPLÍCITO (2026-10-02). Antes, a falha do
    # `read` só parava o programa por causa do `set -e` -- e o `set -e` não
    # vale dentro de um `if`/`||`. Um laço que pergunta outra vez depois de um
    # erro («número fora da lista», «palavra não confere») rodava então sem
    # fim numa tela que fechou (o FIFO de um teste, uma consola desligada).
    # Uma última linha sem Enter ainda conta: devolve-se o que veio, com 0, e
    # é a leitura SEGUINTE que dá o fim.
    if ! IFS= read -r resposta; then
        [ -n "$resposta" ] || return 1
    fi

    # -----------------------------------------------------------------------
    # 🔴 O ENTER DE UMA CONSOLA SÉRIE CHEGA COMO CR, E O `read` DEIXA-O LÁ
    # -----------------------------------------------------------------------
    # MEDIDO a 2026-09-21, a conduzir o instalador pela série de uma VM: o
    # técnico escreve `1` e carrega em Enter; o emulador (PuTTY, minicom, screen)
    # manda `1\r`; o `read` tira o `\n` e **entrega `1\r`**. O resultado, com a
    # lista certa à frente dos olhos:
    #
    #	  1) /dev/sdb       8G        VBOX HARDDISK
    #	Disk number: 1
    #	** Number not in the list. Try again.
    #
    # ⚠️ E o mesmo acontecia à palavra de confirmação: `ERASE\r` nunca seria
    # igual a `ERASE`, e **o instalador recusaria a palavra certa para sempre**.
    # Numa bancada com teclado e ecrã isto nunca aparece — só na consola, que é
    # o único sítio onde este programa vai correr.
    #
    # ⚠️ Tira-se **só o CR final**, e não espaços: o CR é artefacto do terminador
    # de linha, não é coisa que o técnico tenha escrito. Um `ERASE ` com espaço
    # continua a ser recusado, que é o que o portão promete.
    resposta="${resposta%"$(printf '\r')"}"

    printf '%s' "$resposta"
}

# tela_pergunta_secreta -- `tela_pergunta` SEM ECO, para senhas. Mesmo contrato
# de canais (a pergunta em stderr, só a resposta em stdout), do CR e do fim da
# entrada.
#
# ⚠️ O eco repõe-se SEMPRE no fim, ao estado EXACTO em que estava (`stty -g`),
# e não a um `stty echo` genérico: um terminal que o chamador pôs noutro estado
# não pode sair daqui mudado. Num `read` interrompido (Ctrl+C) o eco ficaria
# desligado até ao próximo prompt -- por isso o `tela_prepara_terminal` o repõe
# (`echo`) e a unidade reinicia o terminal (`TTYReset=yes`).
#
# Sem terminal (os testes, um tubo) não há eco para desligar, e o `stty` é
# saltado: a resposta vem da entrada tal como vem.
#
# 🔴 O ENTER NÃO ECOA, e a pergunta seguinte colava-se à linha da senha: escreve-se
# um fim de linha à mão, e só quando o eco esteve mesmo desligado.
tela_pergunta_secreta() {
    printf '%s' "$(_tela_txt "$1")" >&2
    _ps_salvo=""
    if [ -t 0 ] && command -v stty >/dev/null 2>&1; then
        _ps_salvo=$(stty -g 2>/dev/null) || _ps_salvo=""
        [ -z "$_ps_salvo" ] || stty -echo 2>/dev/null || _ps_salvo=""
    fi
    _ps_rc=0
    IFS= read -r resposta || _ps_rc=$?
    if [ -n "$_ps_salvo" ]; then
        stty "$_ps_salvo" 2>/dev/null || true
        printf '\n' >&2
    fi
    if [ "$_ps_rc" -ne 0 ]; then
        [ -n "$resposta" ] || return 1
    fi
    resposta="${resposta%"$(printf '\r')"}"
    printf '%s' "$resposta"
}

# ---------------------------------------------------------------------------
# 🔴 NO MONITOR, O TECLADO NUMÉRICO COMEÇA COM O NUMLOCK DESLIGADO
# ---------------------------------------------------------------------------
# O console do Linux NÃO herda o NumLock da BIOS (o estado inicial do kernel
# é desligado), e o pendrive não leva o `kbd` (sem `setleds`). Com o NumLock
# desligado, o «1» do teclado numérico chega ao `read` como a tecla End --
# `ESC [ 4 ~` -- e não como «1». O técnico, num appliance só com monitor,
# escolhia «1» para Português e caía em inglês sem aviso; no passo do disco
# lia «número fora da lista» com o número certo escrito. Na porta serial isto
# não aparecia: lá o teclado é o do notebook do técnico.
#
# O que o kernel manda com o NumLock desligado (drivers/tty/vt/keyboard.c,
# `k_pad`; leitura de fonte, POR VERIFICAR num teclado USB real):
#
#   0 Insert ESC[2~   1 End    ESC[4~   2 baixo  ESC[B   3 PgDn ESC[6~
#   4 esq.   ESC[D    5 (meio) ESC[G    6 dir.   ESC[C   7 Home ESC[1~
#   8 cima   ESC[A    9 PgUp   ESC[5~
#
# e as formas `ESC O x` dos modos de aplicação (cursor e teclado numérico do
# VT100: `ESC O p`..`ESC O y` são 0..9), que um terminal série pode mandar.
#
# ⚠️ SÓ NAS PERGUNTAS DE NÚMERO (idioma e disco), e nunca na palavra do
# APAGAR: lá a comparação é exacta e assim fica. E a tradução só pode ajudar:
# numa pergunta de número, uma sequência de escape nunca era resposta válida.
# O preço é que as setas do teclado principal mandam os MESMOS bytes (o
# kernel não as distingue) -- uma seta para baixo vira «2». No disco isso
# ainda passa pelo portão, que mostra o disco escolhido e pede a palavra.
_tela_teclado_numerico() {
    _tn_e=$(printf '\033')
    printf '%s' "$1" | LC_ALL=C sed \
        -e "s/${_tn_e}\[2~/0/g;s/${_tn_e}\[4~/1/g;s/${_tn_e}\[B/2/g" \
        -e "s/${_tn_e}\[6~/3/g;s/${_tn_e}\[D/4/g;s/${_tn_e}\[G/5/g" \
        -e "s/${_tn_e}\[C/6/g;s/${_tn_e}\[1~/7/g;s/${_tn_e}\[A/8/g" \
        -e "s/${_tn_e}\[5~/9/g" \
        -e "s/${_tn_e}OB/2/g;s/${_tn_e}OD/4/g;s/${_tn_e}OG/5/g" \
        -e "s/${_tn_e}OC/6/g;s/${_tn_e}OA/8/g" \
        -e "s/${_tn_e}Op/0/g;s/${_tn_e}Oq/1/g;s/${_tn_e}Or/2/g;s/${_tn_e}Os/3/g" \
        -e "s/${_tn_e}Ot/4/g;s/${_tn_e}Ou/5/g;s/${_tn_e}Ov/6/g;s/${_tn_e}Ow/7/g" \
        -e "s/${_tn_e}Ox/8/g;s/${_tn_e}Oy/9/g"
}

# tela_pergunta_numero -- `tela_pergunta`, mais a tradução do teclado
# numérico (ver acima). Mesmo contrato de canais e de fim da entrada.
tela_pergunta_numero() {
    _tpn=$(tela_pergunta "$1") || return 1
    _tela_teclado_numerico "$_tpn"
}

# tela_espera_enter <pergunta> -- espera um Enter e deita fora o que veio.
# 0 com uma linha, 1 no fim da entrada (ver `tela_pergunta`).
tela_espera_enter() {
    tela_pergunta "$1" >/dev/null
}
